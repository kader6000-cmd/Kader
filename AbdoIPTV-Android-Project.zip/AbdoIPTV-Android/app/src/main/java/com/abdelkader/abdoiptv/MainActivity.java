package com.abdelkader.abdoiptv;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);   // يسمح بطلبات السيرفرات (CORS)
        s.setAllowFileAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            private View custom;
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                custom = v; setContentView(v);
            }
            @Override public void onHideCustomView() {
                setContentView(web); custom = null;
            }
        });
        web.addJavascriptInterface(new DL(), "AndroidDL");
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        else if (Build.VERSION.SDK_INT <= 28) requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        web.setFocusable(true);
        web.requestFocus();
        web.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            // مرّر زر الرجوع للتطبيق كما يفعل ريموت LG (الرمز 461)
            web.evaluateJavascript("(function(){var e=new KeyboardEvent('keydown',{keyCode:461,which:461,bubbles:true});document.dispatchEvent(e);})()", null);
            return true;
        }
        return super.onKeyDown(code, e);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    class DL {
        private String enqueue(String url, String name, String ext) {
            try {
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
                if (safe.isEmpty()) safe = "episode";
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setTitle(safe);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AbdoIPTV/" + safe + "." + ext);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                return "ok";
            } catch (Exception e) { return "error: " + e.getMessage(); }
        }
        @JavascriptInterface public String download(String url, String name, String ext) { return enqueue(url, name, ext); }
        @JavascriptInterface public void downloadMany(String json) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    enqueue(o.getString("url"), o.getString("name"), o.optString("ext", "mp4"));
                }
            } catch (Exception ignored) {}
        }
    }
}
