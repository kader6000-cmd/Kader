/* ABDO IPTV 5.0 — UI layer: clock, settings, font size, view tracking */
(function(){
"use strict";
function $(id){return document.getElementById(id)}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}

/* ----- clock (12h + Arabic date) ----- */
var DAYS=["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
var MONTHS=["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
function tick(){
 var d=new Date(),h=d.getHours(),m=d.getMinutes(),ap=h>=12?"PM":"AM";
 h=h%12||12;
 if($("liveClock"))$("liveClock").textContent=h+":"+(m<10?"0":"")+m+" "+ap;
 if($("dateBadge"))$("dateBadge").textContent=DAYS[d.getDay()]+" "+d.getDate()+" "+MONTHS[d.getMonth()]+" "+d.getFullYear();
}
tick();setInterval(tick,15000);

/* ----- font scale ----- */
function applyFs(v){
 v=Number(v)||1;document.documentElement.style.setProperty("--fs",String(v));ls("abdo_fs",String(v));
 var b=document.querySelectorAll("#fontOpts button");for(var i=0;i<b.length;i++)b[i].classList.toggle("on",Number(b[i].dataset.fs)===v);
}
applyFs(ls("abdo_fs")||1);

/* ----- engine preference ----- */
function applyEngine(e){
 e=e==="native"?"native":"auto";ls("abdo_engine",e);
 var b=document.querySelectorAll("#engineOpts button");for(var i=0;i<b.length;i++)b[i].classList.toggle("on",b[i].dataset.engine===e);
 if(window.ABDOPlayer&&ABDOPlayer.setEngine)ABDOPlayer.setEngine(e);
}

/* ----- settings dialog: move existing buttons into it ----- */
function mount(id,host,cls){var el=$(id),h=$(host);if(el&&h){el.classList.remove("hidden");if(cls)el.className=cls;h.appendChild(el)}}
mount("themeBtn","themeHost","secondary");
mount("addBtn","serverHost","secondary");
mount("exitBtn","exitHost","danger");
var sw=document.createElement("button");sw.type="button";sw.className="secondary";sw.textContent="⌂ قائمة السيرفرات";
sw.onclick=function(){closeSettings();if($("homeBtn"))$("homeBtn").click()};
if($("serverHost"))$("serverHost").insertBefore(sw,$("serverHost").firstChild);
["addBtn","exitBtn","themeBtn"].forEach(function(id){var b=$(id);if(b&&id!=="themeBtn")b.addEventListener("click",closeSettings)});

function openSettings(){
 $("settingsDialog").classList.remove("hidden");
 var cur=document.querySelector("#fontOpts button.on")||document.querySelector("#fontOpts button");
 try{cur.focus()}catch(e){}
}
function closeSettings(){var d=$("settingsDialog");if(d&&!d.classList.contains("hidden")){d.classList.add("hidden");try{$("settingsBtn").focus()}catch(e){}}}
var DLGS=["linkDialog","infoDialog","settingsDialog"];
function openIds(){return DLGS.filter(function(id){var d=$(id);return d&&!d.classList.contains("hidden")})}
function closeTop(){var o=openIds();if(!o.length)return false;var id=o[0];if(id==="linkDialog")closeLink();else if(id==="infoDialog")closeInfo();else closeSettings();return true}
window.ABDOUI={openSettings:openSettings,closeSettings:closeSettings,isSettingsOpen:function(){return !$("settingsDialog").classList.contains("hidden")},anyOpen:function(){return openIds().length>0},closeTop:closeTop,openInfo:function(){openInfo()},openLink:function(){openLink()}};
$("settingsBtn").onclick=openSettings;
$("closeSettingsDlg").onclick=closeSettings;
$("settingsDialog").addEventListener("click",function(e){if(e.target===$("settingsDialog"))closeSettings()});
Array.prototype.forEach.call(document.querySelectorAll("#fontOpts button"),function(b){b.onclick=function(){applyFs(b.dataset.fs)}});
Array.prototype.forEach.call(document.querySelectorAll("#engineOpts button"),function(b){b.onclick=function(){applyEngine(b.dataset.engine)}});
applyEngine(ls("abdo_engine")||"auto");
if($("wifiBtn"))$("wifiBtn").onclick=function(){
 var on=navigator.onLine!==false,c=navigator.connection&&navigator.connection.effectiveType;
 var t=$("toast");t.textContent=on?("الاتصال بالإنترنت يعمل"+(c?" ("+c+")":"")):"لا يوجد اتصال بالإنترنت";t.style.display="block";clearTimeout(t._h);t._h=setTimeout(function(){t.style.display="none"},2600);
};

/* ----- track which screen is open ----- */
var home=$("homeView");
function sync(){document.body.classList.toggle("on-home",!home.classList.contains("hidden"))}
sync();
try{new MutationObserver(sync).observe(home,{attributes:true,attributeFilter:["class"]})}catch(e){}

/* ---------- phone link (QR) ---------- */
function openLink(){
 closeSettings();$("linkDialog").classList.remove("hidden");
 var st=$("linkStatus");st.textContent="جارٍ التجهيز…";st.className="link-status";$("linkMode").textContent="";$("linkUrl").textContent="";
 try{$("linkDone").focus()}catch(e){}
 ABDOLink.start(function(t,k){st.textContent=t;st.className="link-status "+(k||"")},function(s){return window.ABDOAddServer?ABDOAddServer(s):{ok:false,msg:"غير متاح"}})
 .then(function(r){
  ABDOQR.draw($("qrCanvas"),r.url,420);
  $("linkUrl").textContent=r.mode==="relay"?r.url:"";
  $("linkMode").textContent=r.mode==="secure"?"🔒 الإرسال مشفّر من الموبايل حتى التلفزيون":r.mode==="plain"?"⚠️ الإرسال بدون تشفير (الجهاز لا يدعم التشفير)":"ℹ️ لم تُضبط صفحة الموبايل بعد — الرمز يفتح صفحة الإرسال العامة. أرسل رسالة بالشكل: الاسم|العنوان|المستخدم|كلمة المرور";
 }).catch(function(e){st.textContent="تعذر إنشاء الرمز: "+(e&&e.message||e);st.className="link-status err"});
}
function closeLink(){try{ABDOLink.stop()}catch(e){}$("linkDialog").classList.add("hidden");var b=$("settingsBtn");try{b.focus()}catch(e){}}
$("closeLinkDlg").onclick=closeLink;$("linkDone").onclick=closeLink;$("linkRenew").onclick=openLink;
$("linkDialog").addEventListener("click",function(e){if(e.target===$("linkDialog"))closeLink()});
["linkBtn","linkBtn2"].forEach(function(id){var b=$(id);if(b)b.onclick=openLink});

/* ---------- server info page ---------- */
function fmtDate(ts){var d=new Date(ts*1000);return d.getDate()+" "+MONTHS[d.getMonth()]+" "+d.getFullYear()}
function infoRow(host,k,v,cls){var r=document.createElement("div");r.className="info-row";var a=document.createElement("span");a.className="info-k";a.textContent=k;var b=document.createElement("b");b.className="info-v "+(cls||"");b.textContent=v;r.appendChild(a);r.appendChild(b);host.appendChild(r)}
function closeInfo(){$("infoDialog").classList.add("hidden");try{$("settingsBtn").focus()}catch(e){}}
function openInfo(){
 closeSettings();var d=$("infoDialog"),body=$("infoBody");d.classList.remove("hidden");body.innerHTML="";
 try{$("infoDone").focus()}catch(e){}
 var s=window.ABDOCurrentServer&&ABDOCurrentServer();
 if(!s){body.textContent="لا يوجد سيرفر محدد. اختر سيرفرًا أولاً.";return}
 var wait=document.createElement("div");wait.className="info-wait";wait.textContent="جارٍ تحميل معلومات الاشتراك…";
 infoRow(body,"اسم السيرفر",s.name||"—");
 infoRow(body,"نوع الاتصال",s.type==="m3u"?"قائمة M3U":"Xtream Codes");
 if(s.type!=="xtream"){
  var host="";try{host=new URL(s.url).origin}catch(e){host=s.url||""}
  infoRow(body,"العنوان",host);
  infoRow(body,"تاريخ انتهاء الاشتراك","غير متاح لقوائم M3U","muted");
  return;
 }
 infoRow(body,"العنوان",s.host||"");
 body.appendChild(wait);
 var tOut=setTimeout(function(){},0);
 ABDOSource.json(ABDOSource.endpoint(s,"")).then(function(j){
  if(wait.parentNode)wait.parentNode.removeChild(wait);
  var ui=j&&j.user_info,si=j&&j.server_info;
  if(!ui){infoRow(body,"الحالة","السيرفر لم يرجع بيانات الاشتراك","bad");return}
  var now=Math.floor(Date.now()/1000),exp=Number(ui.exp_date),hasExp=isFinite(exp)&&exp>0,st=String(ui.status||"").toLowerCase();
  var expired=hasExp&&exp<now,stTxt=st==="active"&&!expired?"فعّال":st==="expired"||expired?"منتهي":st==="banned"?"محظور":st==="disabled"?"موقوف":(ui.status||"—");
  infoRow(body,"حالة الاشتراك",stTxt,(stTxt==="فعّال")?"good":"bad");
  if(hasExp){
   var days=Math.ceil((exp-now)/86400);
   infoRow(body,"تاريخ انتهاء الاشتراك",fmtDate(exp),expired?"bad":(days<=7?"warn":"good"));
   infoRow(body,"المتبقي",expired?("انتهى منذ "+Math.abs(days)+" يوم"):(days+" يوم"),expired?"bad":(days<=7?"warn":"good"));
  }else infoRow(body,"تاريخ انتهاء الاشتراك","غير محدود","good");
  if(ui.created_at&&Number(ui.created_at)>0)infoRow(body,"بداية الاشتراك",fmtDate(Number(ui.created_at)));
  infoRow(body,"نوع الاشتراك",String(ui.is_trial)==="1"?"تجريبي":"مدفوع");
  if(ui.max_connections!=null)infoRow(body,"الاتصالات",(ui.active_cons!=null?ui.active_cons:"0")+" / "+ui.max_connections);
  infoRow(body,"اسم المستخدم",s.username||ui.username||"");
  infoRow(body,"كلمة المرور","••••••••");
  if(Array.isArray(ui.allowed_output_formats)&&ui.allowed_output_formats.length)infoRow(body,"صيغ البث",ui.allowed_output_formats.join(" · "));
  if(si&&si.timezone)infoRow(body,"المنطقة الزمنية",si.timezone);
 }).catch(function(e){
  if(wait.parentNode)wait.parentNode.removeChild(wait);
  infoRow(body,"تعذر جلب المعلومات",e&&e.message?e.message:"تحقق من الاتصال بالسيرفر","bad");
 });
}
$("closeInfoDlg").onclick=closeInfo;$("infoDone").onclick=closeInfo;$("infoRefresh").onclick=openInfo;
$("infoDialog").addEventListener("click",function(e){if(e.target===$("infoDialog"))closeInfo()});
if($("infoBtn2"))$("infoBtn2").onclick=openInfo;
})();
(function(){var pv=document.getElementById("playerView");if(!pv)return;function s(){document.body.classList.toggle("in-player",!pv.classList.contains("hidden"))}s();try{new MutationObserver(s).observe(pv,{attributes:true,attributeFilter:["class"]})}catch(e){}})();
