/* ABDO IPTV 5.2 — add a server from your phone: TV shows a QR, phone page posts the (encrypted) server to a relay topic, TV receives it live */
(function(w){"use strict";
var es=null,topic="",keyObj=null,keyB64="",seen={},startedAt=0,cbStatus=null,cbServer=null,pageUrl="",encrypted=false,lastRetry=0;
function cfg(){var page="";try{page=localStorage.getItem("abdo_phone_page")||""}catch(e){}
 return {relay:String(w.ABDO_RELAY||"https://ntfy.sh").replace(/\/+$/,""),page:String(page||w.ABDO_PHONE_PAGE||"").trim()}}
function rnd(n){var a=new Uint8Array(n),s="",c="abcdefghijklmnopqrstuvwxyz0123456789";(w.crypto||w.msCrypto).getRandomValues(a);for(var i=0;i<n;i++)s+=c[a[i]%36];return s}
function b64u(bytes){var s="";for(var i=0;i<bytes.length;i++)s+=String.fromCharCode(bytes[i]);return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function unb64u(t){t=t.replace(/-/g,"+").replace(/_/g,"/");while(t.length%4)t+="=";var s=atob(t),a=new Uint8Array(s.length);for(var i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a}
function canCrypto(){return !!(w.crypto&&w.crypto.subtle&&w.crypto.subtle.importKey)}
function status(t,kind){if(cbStatus)cbStatus(t,kind||"")}

function parseServer(text){
 var o=null;text=String(text||"").trim();
 try{o=JSON.parse(text)}catch(e){}
 if(!o||typeof o!=="object"){ /* plain-text fallback: name|host|user|pass  or  name|m3u-url  or just a URL */
  var parts=text.split("|").map(function(x){return x.trim()});
  if(parts.length>=4)o={n:parts[0],t:"xtream",h:parts[1],u:parts[2],p:parts.slice(3).join("|")};
  else if(parts.length===2)o={n:parts[0],t:"m3u",m:parts[1]};
  else if(/^https?:\/\//i.test(text))o={n:"سيرفر من الموبايل",t:"m3u",m:text};
  else return null;
 }
 var name=String(o.n||o.name||"").trim()||"سيرفر من الموبايل",type=(o.t||o.type||"xtream")==="m3u"?"m3u":"xtream";
 var s={id:"abdo-"+Date.now()+"-"+Math.floor(Math.random()*1000),name:name.slice(0,60),type:type};
 if(type==="m3u"){s.url=String(o.m||o.url||"").trim();if(!/^https?:\/\//i.test(s.url))return null}
 else{s.host=String(o.h||o.host||"").trim().replace(/\/+$/,"");s.username=String(o.u||o.username||"").trim();s.password=String(o.p||o.password||"");
  if(!/^https?:\/\//i.test(s.host)||!s.username||!s.password)return null}
 return s;
}
function decrypt(msg){
 var raw=unb64u(msg.trim()),iv=raw.slice(0,12),ct=raw.slice(12);
 return w.crypto.subtle.decrypt({name:"AES-GCM",iv:iv},keyObj,ct).then(function(pt){return new TextDecoder().decode(pt)});
}
function onMessage(d){
 if(!d||(d.event&&d.event!=="message")||!d.message)return;
 if(d.id){if(seen[d.id])return;seen[d.id]=1}
 if(d.time&&d.time<startedAt-5)return; /* ignore anything older than this QR */
 var p=encrypted?Promise.resolve().then(function(){return decrypt(d.message)}):Promise.resolve(d.message);
 p.then(function(text){
  var s=parseServer(text);
  if(!s){status("وصلت رسالة لكن بياناتها غير صحيحة","err");return}
  if(cbServer){var r=cbServer(s);status(r&&r.ok===false?(r.msg||"تعذر الحفظ"):("تمت إضافة السيرفر: "+s.name),r&&r.ok===false?"err":"ok")}
 },function(){status("تعذر فك تشفير رسالة (تجاهلتها)","err")});
}
function open(){
 close(false);var c=cfg();
 es=new EventSource(c.relay+"/"+topic+"/sse");
 es.onopen=function(){status("جاهز — امسح الـ QR من الموبايل","wait")};
 es.onmessage=function(e){try{onMessage(JSON.parse(e.data))}catch(x){}};
 es.onerror=function(){status("إعادة الاتصال بخدمة الربط…","err")};
}
function close(clear){if(es){try{es.close()}catch(e){}es=null}if(clear){topic="";keyObj=null;keyB64="";seen={}}}

/* start(): returns Promise<{url,text,topic,mode}> */
function start(onStatus,onServer){
 cbStatus=onStatus;cbServer=onServer;close(true);
 var c=cfg();topic="abdo"+rnd(20);startedAt=Math.floor(Date.now()/1000);encrypted=false;pageUrl="";
 var useKey=!!c.page&&canCrypto();
 var pk=useKey?Promise.resolve().then(function(){var raw=new Uint8Array(16);w.crypto.getRandomValues(raw);keyB64=b64u(raw);
   return w.crypto.subtle.importKey("raw",raw,{name:"AES-GCM"},false,["decrypt"])}).then(function(k){keyObj=k;encrypted=true}):Promise.resolve();
 return pk.then(function(){
  var url,mode;
  if(c.page){url=c.page+(c.page.indexOf("?")<0?"?":"&")+"t="+topic+(c.relay!=="https://ntfy.sh"?"&r="+encodeURIComponent(c.relay):"")+(encrypted?"#k="+keyB64:"");mode=encrypted?"secure":"plain"}
  else{url=c.relay+"/"+topic;mode="relay"}
  open();
  return {url:url,topic:topic,mode:mode,relay:c.relay};
 });
}
function stop(){close(true);cbStatus=cbServer=null}
w.ABDOLink={start:start,stop:stop,parse:parseServer,config:cfg,_onMessage:onMessage};
})(window);
