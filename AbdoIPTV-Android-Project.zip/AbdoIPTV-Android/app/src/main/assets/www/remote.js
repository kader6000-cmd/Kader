(function(w){"use strict";
var fn=null,playing=function(){return false},lastBack=0,backTimer=null;
function name(e){var c=e.keyCode||e.which,k=e.key||"";if([27,461,10009].indexOf(c)>=0||k==="Escape"||k==="Backspace")return "BACK";if(c===13||k==="Enter"||k===" ")return "OK";if(c===37||k==="ArrowLeft")return "LEFT";if(c===38||k==="ArrowUp")return "UP";if(c===39||k==="ArrowRight")return "RIGHT";if(c===40||k==="ArrowDown")return "DOWN";if(c===415)return "PLAY";if(c===19)return "PAUSE";if(c===413)return "STOP";if(c===412)return "REWIND";if(c===417)return "FAST_FORWARD";if(c===403)return "RED";if(c===404)return "GREEN";if(c===405)return "YELLOW";if(c===406)return "BLUE";if(c===457)return "INFO";if(c>=48&&c<=57)return "NUM"+(c-48);if(c>=96&&c<=105)return "NUM"+(c-96);if(c===427)return "CHANNEL_UP";if(c===428)return "CHANNEL_DOWN";return ""}
function visible(el){if(!el||!el.getBoundingClientRect)return false;var r=el.getBoundingClientRect(),s=w.getComputedStyle(el);return r.width>0&&r.height>0&&s.visibility!=="hidden"&&s.display!=="none"&&!el.disabled}
function candidates(){var m=document.querySelector(".modal:not(.hidden)");if(m)return Array.prototype.slice.call(m.querySelectorAll("button:not(:disabled),input:not(:disabled),select:not(:disabled)")).filter(visible);return Array.prototype.slice.call(document.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),[tabindex="0"]')).filter(visible)}
function move(dir){
 var a=document.activeElement;
 if(a&&(a.tagName==="INPUT"||a.tagName==="TEXTAREA")&&(dir==="LEFT"||dir==="RIGHT"))return false;
 var all=candidates();if(!all.length)return false;
 if(!a||all.indexOf(a)<0){all[0].focus();return true}
 var ar=a.getBoundingClientRect(),ax=ar.left+ar.width/2,ay=ar.top+ar.height/2,best=null,score=Infinity;
 all.forEach(function(el){if(el===a)return;var r=el.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,dx=x-ax,dy=y-ay,primary,secondary;
 if(dir==="LEFT"){if(dx>=-2)return;primary=-dx;secondary=Math.abs(dy)}
 else if(dir==="RIGHT"){if(dx<=2)return;primary=dx;secondary=Math.abs(dy)}
 else if(dir==="UP"){if(dy>=-2)return;primary=-dy;secondary=Math.abs(dx)}
 else {if(dy<=2)return;primary=dy;secondary=Math.abs(dx)}
 var v=primary+secondary*1.65;if(secondary>primary*2.5)v+=secondary*2;
 if(v<score){score=v;best=el}
 });
 if(best){
  best.focus({preventScroll:true});
  try{
    var pane=best.closest("#items,#groups,#episodesList,#seasonsList,#servers");
    if(pane){
      var pr=pane.getBoundingClientRect(),br=best.getBoundingClientRect();
      if(br.bottom>pr.bottom-20)pane.scrollTop+=(br.bottom-pr.bottom)+40;
      else if(br.top<pr.top+20)pane.scrollTop-=(pr.top-br.top)+40;
    }else{
      best.scrollIntoView({block:"nearest",inline:"nearest"});
    }
  }catch(e){}
  return true
 }
 var activePane=a&&a.closest&&a.closest("#items,#groups,#episodesList,#seasonsList,#servers");
 if(activePane&&(dir==="DOWN"||dir==="UP")){activePane.scrollTop+=(dir==="DOWN"?280:-280);return true;}
 return false
}
document.addEventListener("keydown",function(e){
 var k=name(e);if(!k)return;
 if(k==="LEFT"||k==="RIGHT"||k==="UP"||k==="DOWN"){
  if(playing()){if(fn){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();fn(k,e)}return}
  if(move(k)){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation()}return;
 }
 if(k==="BACK"){
  e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();
  var now=Date.now();
  if(now-lastBack<1800){lastBack=0;if(backTimer){clearTimeout(backTimer);backTimer=null}if(fn)fn("BACK_DOUBLE",e)}
  else{lastBack=now;if(fn)fn("BACK",e);backTimer=setTimeout(function(){lastBack=0;backTimer=null},1850)}
  return;
 }
 if(playing()||k==="PLAY"||k==="PAUSE"||k==="STOP"||k==="REWIND"||k==="FAST_FORWARD"){
  if(fn){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();fn(k,e)}
 }
},true);
// Magic Remote pointer movement does not auto-select or steal focus; click remains native.
w.ABDORemote={bind:function(f,p){fn=f;playing=p||function(){return false}},key:name,move:move};
})(window);
