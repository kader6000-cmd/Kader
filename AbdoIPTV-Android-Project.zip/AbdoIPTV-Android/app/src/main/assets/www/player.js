/* ABDO IPTV 5.0 — Player engine
   - Native webOS player first (best hardware decode), with automatic fallback chain
   - hls.js (HLS) and mpegts.js (MPEG-TS live) as modern engines: loaded from libs/ if bundled, otherwise from CDN
   - Stall watchdog + auto-reconnect, buffering indicator, channel banner, number zapping,
     accelerated seek, sleep timer, stats overlay, remote-friendly settings navigation
   Public API is unchanged: ABDOPlayer.{init,play,remote,stop,fullscreen,setQueue,isActive} (+ setEngine) */
(function(w){"use strict";
var LIBS={
 hls:["libs/hls.min.js","https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js"],
 ts:["libs/mpegts.js","https://cdn.jsdelivr.net/npm/mpegts.js@1.7.3/dist/mpegts.js"]
};
var v=null,inited=false,active=false,goBack=null,fit=0,rate=0,timer=null,queue=[],queueIndex=-1,queueKind="live",serverId="",resumeKey="",lastSaved=0,lastPaint=0,resumeApplied=false;
var rates=[1,1.25,1.5,1.75,2,.75],fits=["contain","cover","fill"],fitNames=["احتواء","ملء","تمديد"];
var pref="auto",hls=null,mp=null,engineName="native",curUrl="",baseUrl="",attempts=[],attemptIdx=0,rounds=0,hlsFix=0,medFix=0,session=0;
var libP={hls:null,ts:null},watch=null,stallSecs=0,lastT=-1,navMode=false,bannerT=null,numBuf="",numT=null,seekCount=0,lastSeekAt=0;
var sleepOpts=[0,15,30,60,90],sleepIdx=0,sleepTimer=null,sleepEnd=0,statsOn=false,statsT=null;

function $(id){return document.getElementById(id)}
var quietUntil=0,mx=-1,my2=-1,lastMoveShow=0;
function hideHud(){var wrap=$("playerWrap");if(!wrap)return;clearTimeout(timer);navMode=false;try{if(document.activeElement&&document.activeElement.blur)document.activeElement.blur()}catch(e){}wrap.classList.remove("hud-visible");var m=$("settingsMenu");if(m)m.classList.add("hidden");closeEpPanel()}
function show(){var wrap=$("playerWrap");if(!wrap)return;wrap.classList.add("hud-visible");clearTimeout(timer);
 timer=setTimeout(function(){if(!active||!v)return;if(navMode||(v&&v.paused&&false)){/* menu mode: keep a little longer, then leave it */timer=setTimeout(function(){if(active)hideHud()},12000);return}hideHud()},navMode?12000:6000)}
function fmt(n){if(!isFinite(n)||n<0)return "00:00";var h=Math.floor(n/3600),m=Math.floor(n%3600/60),s=Math.floor(n%60),mm=String(m).padStart(2,"0"),ss=String(s).padStart(2,"0");return h?String(h).padStart(2,"0")+":"+mm+":"+ss:mm+":"+ss}
function status(s){if($("playStatus"))$("playStatus").textContent=s}
function spin(on,txt){var b=$("bufferSpin");if(!b)return;b.classList.toggle("hidden",!on);if(txt&&$("bufferText"))$("bufferText").textContent=txt}

/* ---------- resume ---------- */
function saveResume(force){
 if(!v||!resumeKey||queueKind==="live")return;
 var now=Date.now();if(!force&&now-lastSaved<10000)return;lastSaved=now;
 try{var t=v.currentTime,d=v.duration;if(isFinite(t)&&t>10&&(!isFinite(d)||d<=0||t<d-20))localStorage.setItem(resumeKey,JSON.stringify({time:t,duration:isFinite(d)?d:0}));}catch(e){}
}
function restoreResume(){
 if(!v||!resumeKey||queueKind==="live"||resumeApplied)return;
 resumeApplied=true;
 try{var raw=localStorage.getItem(resumeKey);if(!raw)return;var saved=JSON.parse(raw),t=Number(saved.time),d=Number(saved.duration);
 if(!isFinite(t)||t<10)return;
 if(isFinite(v.duration)&&v.duration>0&&t>v.duration-20){localStorage.removeItem(resumeKey);return}
 if(isFinite(v.duration)&&v.duration>0&&d>0&&Math.abs(v.duration-d)>Math.max(120,d*.25))return;
 v.currentTime=t;status("تم الاستكمال من "+fmt(t));paint(true);
 }catch(e){}
}
function paint(force){
 if(!v||!active)return;
 var now=Date.now();
 if(!force&&now-lastPaint<950)return;
 lastPaint=now;
 saveResume(false);
 $("playPause").textContent=v.paused?"▶":"Ⅱ";
 $("currentTime").textContent=fmt(v.currentTime);
 $("duration").textContent=queueKind==="live"?"مباشر":fmt(v.duration);
 if(isFinite(v.duration)&&v.duration>0)$("seekBar").value=Math.round(v.currentTime/v.duration*1000);
}

/* ---------- engine libraries (local libs/ first, then CDN) ---------- */
function loadScript(src){return new Promise(function(res,rej){var s=document.createElement("script"),done=false;
 var t=setTimeout(function(){if(!done){done=true;try{s.remove()}catch(e){}rej()}},7000);
 s.onload=function(){if(!done){done=true;clearTimeout(t);res()}};
 s.onerror=function(){if(!done){done=true;clearTimeout(t);try{s.remove()}catch(e){}rej()}};
 s.src=src;document.head.appendChild(s)})}
function libReady(n){return n==="hls"?!!(w.Hls&&w.Hls.isSupported&&w.Hls.isSupported()):!!(w.mpegts&&w.mpegts.getFeatureList&&w.mpegts.isSupported&&w.mpegts.isSupported())}
function tryLoad(list,n,i){if(libReady(n))return Promise.resolve(true);if(i>=list.length)return Promise.resolve(false);return loadScript(list[i]).then(function(){return libReady(n)?true:tryLoad(list,n,i+1)},function(){return tryLoad(list,n,i+1)})}
function lib(n){if(!libP[n])libP[n]=tryLoad(LIBS[n],n,0);return libP[n]}

/* ---------- engine management ---------- */
function destroy(){
 if(hls){try{hls.destroy()}catch(e){}hls=null}
 if(mp){try{mp.pause();mp.unload();mp.detachMediaElement();mp.destroy()}catch(e){}mp=null}
 engineName="native";
}
function isHlsUrl(u){return /\.m3u8(?:[?#]|$)/i.test(u)}
function isTsUrl(u){return /\.ts(?:[?#]|$)/i.test(u)}
function isFileUrl(u){return /\.(?:mp4|mkv|avi|mov|m4v|webm)(?:[?#]|$)/i.test(u)}
function altUrl(u){
 if(isHlsUrl(u))return u.replace(/\.m3u8(?=(?:[?#]|$))/i,".ts");
 if(isTsUrl(u)&&queueKind==="live")return u.replace(/\.ts(?=(?:[?#]|$))/i,".m3u8");
 return "";
}
function buildPlan(url){
 var plan=[],kindOf=function(u){return isHlsUrl(u)?"hls":(isTsUrl(u)||(queueKind==="live"&&!isFileUrl(u)))?"ts":""};
 plan.push({e:"native",u:url});
 if(pref==="auto"){var k=kindOf(url);if(k)plan.push({e:k,u:url})}
 var alt=altUrl(url);
 if(alt){plan.push({e:"native",u:alt});if(pref==="auto"){var k2=kindOf(alt);if(k2)plan.push({e:k2,u:alt})}}
 return plan;
}
function begin(url){
 session++;baseUrl=url;attempts=buildPlan(url);attemptIdx=0;rounds=0;hlsFix=0;medFix=0;
 if(pref==="auto"){lib("hls");lib("ts")} /* warm up in background */
 runAttempt();
}
function runAttempt(){
 var my=session,a=attempts[attemptIdx];if(!a){return giveUp()}
 destroy();stallSecs=0;lastT=-1;curUrl=a.u;
 try{v.pause();v.removeAttribute("src");v.load()}catch(e){}
 if(a.e==="native"){
  engineName="native";v.dataset.alt=a.u!==baseUrl?"1":"";
  v.src=a.u;v.load();status(attemptIdx?"جارٍ تجربة مسار بديل":"جارٍ بدء البث");spin(true,"جارٍ التحميل…");startPlay();return;
 }
 spin(true,"جارٍ تجهيز المشغل الحديث…");
 lib(a.e).then(function(ok){
  if(my!==session||!active)return;
  if(!ok)return nextAttempt("المكتبة غير متاحة");
  try{
   if(a.e==="hls"){
    engineName="hls.js";
    hls=new w.Hls({enableWorker:true,lowLatencyMode:false,maxBufferLength:30,backBufferLength:30,capLevelToPlayerSize:false,startLevel:-1,manifestLoadingMaxRetry:3,levelLoadingMaxRetry:3,fragLoadingMaxRetry:4});
    hls.on(w.Hls.Events.ERROR,function(ev,d){if(my!==session)return;onHlsError(d)});
    hls.on(w.Hls.Events.MANIFEST_PARSED,function(){startPlay()});
    hls.attachMedia(v);hls.loadSource(a.u);
   }else{
    engineName="mpegts.js";
    mp=w.mpegts.createPlayer({type:"mpegts",isLive:queueKind==="live",url:a.u},{enableWorker:true,liveBufferLatencyChasing:queueKind==="live",liveBufferLatencyMaxLatency:12,liveBufferLatencyMinRemain:2,lazyLoad:false});
    mp.on(w.mpegts.Events.ERROR,function(){if(my!==session)return;nextAttempt("خطأ في البث")});
    mp.attachMediaElement(v);mp.load();startPlay();
   }
   status("المشغل الحديث: "+engineName);
  }catch(e){nextAttempt("تعذر تشغيل المحرك")}
 });
}
function onHlsError(d){
 if(!d||!d.fatal)return;
 if(d.type==="networkError"&&hlsFix<3){hlsFix++;spin(true,"إعادة الاتصال…");try{hls.startLoad()}catch(e){}return}
 if(d.type==="mediaError"&&medFix<2){medFix++;try{hls.recoverMediaError()}catch(e){}return}
 nextAttempt("خطأ في HLS");
}
function nextAttempt(why){
 if(!active)return;
 attemptIdx++;
 if(attemptIdx<attempts.length){status("تعذر المسار الحالي — نجرب مساراً آخر");runAttempt();return}
 giveUp(why);
}
function giveUp(why){
 if(!active)return;
 if(queueKind==="live"&&rounds<4){
  rounds++;var wait=[2,4,6,10][rounds-1]*1000,my=session;
  status("انقطع البث — إعادة المحاولة "+rounds+"/4");spin(true,"إعادة الاتصال ("+rounds+"/4)…");
  setTimeout(function(){if(my===session&&active){attemptIdx=0;runAttempt()}},wait);return;
 }
 spin(false);status("تعذر التشغيل — تأكد من السيرفر أو جرّب القناة/الحلقة مرة أخرى");show();
}
function startPlay(){
 var my=session,p=v.play();
 if(p&&p.then)p.then(function(){if(my===session){status("يعمل"+(engineName!=="native"?" • "+engineName:""));show()}}).catch(function(e){if(my===session&&e&&e.name==="NotAllowedError"){spin(false);status("اضغط OK لبدء التشغيل");show()}});
}
function setEngine(e){pref=e==="native"?"native":"auto";if(active&&curUrl&&v&&!v.paused){/* applies on next play */}}

/* ---------- watchdog: detect frozen / stalled playback ---------- */
function startWatch(){
 clearInterval(watch);
 watch=setInterval(function(){
  if(!active||!v)return;
  if(statsOn)drawStats();
  if(sleepEnd&&Date.now()>=sleepEnd){sleepIdx=0;sleepEnd=0;if($("sleepBtn"))$("sleepBtn").textContent="مؤقت النوم";toastMsg("انتهى مؤقت النوم");stop();return}
  if(v.paused||v.seeking||v.ended){stallSecs=0;lastT=v.currentTime;return}
  var t=v.currentTime;
  if(Math.abs(t-lastT)<.01){
   stallSecs++;
   if(stallSecs>=2)spin(true,stallSecs>=6?"ضعف في الاتصال…":"جارٍ التحميل…");
   var limit=queueKind==="live"?12:25;
   if(stallSecs>=limit){stallSecs=0;status("تجمّد البث — إعادة الاتصال");nextAttempt("تجمد")}
  }else{stallSecs=0;lastT=t;spin(false)}
 },1000);
}
function toastMsg(m){var t=$("toast");if(!t)return;t.textContent=m;t.style.display="block";clearTimeout(t._p);t._p=setTimeout(function(){t.style.display="none"},2600)}

/* ---------- settings menu: quality / audio / subtitles ---------- */
function menu(which){$("settingsMenu").classList.remove("hidden");$("qualityOptions").classList.toggle("hidden",which!=="quality");$("audioOptions").classList.toggle("hidden",which!=="audio");$("subtitleOptions").classList.toggle("hidden",which!=="subtitle");show();
 try{var f=$("settingsMenu").querySelector("button");if(f&&navMode)f.focus()}catch(e){}}
function addOption(host,label,fn){var b=document.createElement("button");b.type="button";b.textContent=label;b.onclick=fn;host.appendChild(b)}
function tracks(){
 var a=$("audioOptions"),sub=$("subtitleOptions");a.innerHTML="";sub.innerHTML="";
 try{
  if(hls&&hls.audioTracks&&hls.audioTracks.length>1){hls.audioTracks.forEach(function(t,i){addOption(a,t.name||t.lang||("مسار صوتي "+(i+1)),function(){hls.audioTrack=i;show()})})}
  else{var ats=v.audioTracks;if(ats&&ats.length){for(let i=0;i<ats.length;i++){(function(n){addOption(a,ats[n].label||ats[n].language||("مسار صوتي "+(n+1)),function(){for(let j=0;j<ats.length;j++)ats[j].enabled=j===n;show()})})(i)}}else a.textContent="لا توجد مسارات صوتية إضافية في هذا البث."}
 }catch(e){a.textContent="المسارات الصوتية غير مدعومة"}
 addOption(sub,"إيقاف الترجمة",function(){try{if(hls)hls.subtitleTrack=-1;for(let i=0;i<v.textTracks.length;i++)v.textTracks[i].mode="disabled"}catch(e){}show()});
 try{var ts=v.textTracks,found=0;for(let i=0;i<ts.length;i++)if(ts[i].kind==="subtitles"||ts[i].kind==="captions"){found++;(function(n){addOption(sub,ts[n].label||ts[n].language||("ترجمة "+(n+1)),function(){for(let j=0;j<ts.length;j++)ts[j].mode=j===n?"showing":"disabled";show()})})(i)}if(!found)sub.appendChild(document.createTextNode("لا توجد مسارات ترجمة مدمجة في هذا البث."))}catch(e){sub.appendChild(document.createTextNode("الترجمة غير مدعومة"))}
}
function quality(url){
 var host=$("qualityOptions");host.innerHTML="";
 if(hls&&hls.levels&&hls.levels.length>1){
  addOption(host,"تلقائي"+(hls.autoLevelEnabled?" ✓":""),function(){hls.currentLevel=-1;show();quality(url)});
  hls.levels.forEach(function(l,i){addOption(host,(l.height?l.height+"p":(Math.round(l.bitrate/1000)+"k"))+(hls.currentLevel===i?" ✓":""),function(){hls.currentLevel=i;show();quality(url)})});
  return;
 }
 if(!isHlsUrl(url)){host.textContent="الجودة يحددها مصدر البث لهذا الرابط.";return}
 ABDOSource.get(url).then(function(text){var lines=text.split(/\r?\n/),opts=[];for(var i=0;i<lines.length;i++)if(lines[i].indexOf("#EXT-X-STREAM-INF")===0){var res=(lines[i].match(/RESOLUTION=(\d+)x(\d+)/)||[])[2],lab=res?res+"p":"جودة";var next=lines.slice(i+1).find(function(x){return x.trim()&&x.trim()[0]!=="#"});if(next)opts.push({label:lab,url:new URL(next.trim(),url).href})}
 if(!opts.length){host.textContent="هذا رابط HLS بجودة واحدة؛ لا توجد اختيارات إضافية.";return}
 opts.forEach(function(o){addOption(host,o.label,function(){var name=$("playingTitle").textContent;play(name,o.url)})});
 }).catch(function(){host.textContent="تعذر قراءة قائمة الجودات."});
}

/* ---------- misc controls ---------- */
function enterFullscreen(){
 var wrap=$("playerWrap"),ok=false;
 try{
  var fs=document.fullscreenElement||document.webkitFullscreenElement;
  if(fs){var ex=document.exitFullscreen||document.webkitExitFullscreen;if(ex){var r0=ex.call(document);if(r0&&r0.catch)r0.catch(function(){})}}
  else if(wrap&&wrap.requestFullscreen){var q=wrap.requestFullscreen();if(q&&q.catch)q.catch(function(){});ok=true}
  else if(wrap&&wrap.webkitRequestFullscreen){wrap.webkitRequestFullscreen();ok=true}
 }catch(e){}
 /* always give the clean full-screen picture: hide every on-screen control */
 quietUntil=Date.now()+2500;hideHud();status("ملء الشاشة — اضغط أي زر لإظهار التحكم");
 return ok||true;
}
function cycleAspect(){fit=(fit+1)%fits.length;v.style.objectFit=fits[fit];if($("aspectBtn"))$("aspectBtn").textContent="العرض: "+fitNames[fit];status("نسبة العرض: "+fitNames[fit]);show()}
function cycleSpeed(){rate=(rate+1)%rates.length;v.playbackRate=rates[rate];$("speedBtn").textContent="السرعة "+rates[rate]+"x";show()}
function cycleSleep(){
 sleepIdx=(sleepIdx+1)%sleepOpts.length;var m=sleepOpts[sleepIdx];
 clearTimeout(sleepTimer);sleepEnd=m?Date.now()+m*60000:0;
 $("sleepBtn").textContent=m?("النوم بعد "+m+" د"):"مؤقت النوم";toastMsg(m?("سيتوقف التشغيل بعد "+m+" دقيقة"):"تم إلغاء مؤقت النوم");show();
}
function drawStats(){
 var b=$("statsBox");if(!b||!v)return;
 var buf=0;try{for(var i=0;i<v.buffered.length;i++)if(v.buffered.start(i)<=v.currentTime&&v.buffered.end(i)>=v.currentTime)buf=v.buffered.end(i)-v.currentTime}catch(e){}
 var q=v.getVideoPlaybackQuality?v.getVideoPlaybackQuality():null,lines=["المحرك   : "+engineName,"الدقة    : "+(v.videoWidth||0)+"×"+(v.videoHeight||0),"المخزن   : "+buf.toFixed(1)+" ث"];
 if(q)lines.push("إطارات مفقودة : "+q.droppedVideoFrames+" / "+q.totalVideoFrames);
 if(hls&&hls.bandwidthEstimate)lines.push("السرعة   : "+(hls.bandwidthEstimate/1e6).toFixed(1)+" Mbps");
 b.textContent=lines.join("\n");
}
function toggleStats(){statsOn=!statsOn;$("statsBox").classList.toggle("hidden",!statsOn);if(statsOn)drawStats();show()}
function banner(item){
 var b=$("chanBanner");if(!b||queueKind!=="live")return;
 var num=item&&item.raw&&item.raw.num?item.raw.num:"";
 $("chanNum").textContent=num;$("chanName").textContent=item?item.name:$("playingTitle").textContent;
 $("chanInfo").textContent=queue.length?("▲ التالية  ▼ السابقة"):"";
 b.classList.remove("hidden");clearTimeout(bannerT);bannerT=setTimeout(function(){b.classList.add("hidden")},4500);
}

/* ---------- init ---------- */
function init(back){
 v=$("player");if(back)goBack=back;if(!v||inited)return;
 inited=true;
 try{var sp=localStorage.getItem("abdo_engine");if(sp)pref=sp==="native"?"native":"auto"}catch(e){}
 v.removeAttribute("controls");v.playsInline=true;
 v.addEventListener("timeupdate",function(){paint(false)});
 ["play","pause","loadedmetadata"].forEach(function(e){v.addEventListener(e,function(){paint(true)})});
 v.addEventListener("loadedmetadata",restoreResume);
 v.addEventListener("pause",function(){saveResume(true)});
 v.addEventListener("waiting",function(){if(active)spin(true,"جارٍ التحميل…")});
 v.addEventListener("playing",function(){spin(false);stallSecs=0;rounds=0;status("يعمل"+(engineName!=="native"?" • "+engineName:""))});
 v.addEventListener("canplay",function(){spin(false)});
 v.addEventListener("ended",function(){if(!active)return;if(queueKind==="live")nextAttempt("انتهى البث");else if(isSeries()&&queueIndex<queue.length-1){toastMsg("الحلقة التالية…");stepEpisode(1)}});
 $("prevEp").onclick=function(){stepEpisode(-1)};$("nextEp").onclick=function(){stepEpisode(1)};$("epListBtn").onclick=openEpPanel;$("epPanelClose").onclick=closeEpPanel;
 $("playPause").onclick=toggle;$("back10").onclick=function(){seek(-10)};$("forward10").onclick=function(){seek(10)};
 $("seekBar").oninput=function(){if(isFinite(v.duration))v.currentTime=v.duration*this.value/1000;show()};
 $("volumeBar").oninput=function(){v.volume=Number(this.value);v.muted=false;show()};
 $("volumeBtn").onclick=function(){v.muted=!v.muted;this.textContent=v.muted?"🔇 كتم":"🔊 الصوت";show()};
 $("closePlayer").onclick=stop;$("fullscreenBtn").onclick=function(){enterFullscreen()};
 $("speedBtn").onclick=cycleSpeed;$("aspectBtn").onclick=cycleAspect;$("sleepBtn").onclick=cycleSleep;$("infoBtn").onclick=toggleStats;
 $("qualityBtn").onclick=function(){menu("quality");quality(curUrl||v.currentSrc||v.src)};
 $("audioBtn").onclick=function(){tracks();menu("audio")};
 $("subtitleBtn").onclick=function(){tracks();menu("subtitle")};
 $("moreBtn").onclick=function(){menu("quality");quality(curUrl||v.currentSrc||v.src)};
 $("closeSettings").onclick=function(){$("settingsMenu").classList.add("hidden");show()};
 v.addEventListener("loadedmetadata",tracks);
 var wrap=$("playerWrap"),lastTap=0;
 function isControlTargetEarly(t){return !!(t&&t.closest&&t.closest("button,input,select,a,.settings-menu,.ep-panel"))}
 wrap.addEventListener("mousemove",function(e){
  if(Date.now()<quietUntil){mx=e.clientX;my2=e.clientY;return}
  var dx=Math.abs(e.clientX-mx),dy=Math.abs(e.clientY-my2);mx=e.clientX;my2=e.clientY;
  if(dx+dy<14)return;var n=Date.now();if(n-lastMoveShow<500)return;lastMoveShow=n;show()});
 wrap.addEventListener("click",function(e){if(!isControlTargetEarly(e.target)){if(wrap.classList.contains("hud-visible"))hideHud();else show()}});
 function isControlTarget(t){return !!(t&&t.closest&&t.closest("button,input,select,a,.settings-menu"))}
 wrap.addEventListener("dblclick",function(e){if(isControlTarget(e.target))return;enterFullscreen()});
 wrap.addEventListener("touchend",function(e){if(isControlTarget(e.target))return;var now=Date.now();if(now-lastTap<420){e.preventDefault();enterFullscreen();lastTap=0}else lastTap=now},{passive:false});
 v.addEventListener("error",function(){if(!active)return;if(engineName!=="native")return; /* js engines report their own errors */ nextAttempt("خطأ في التشغيل")});
}

/* ---------- series: next / previous episode + episode list ---------- */
function isSeries(){return queueKind==="series"&&queue.length>0}
function updateEpUi(){
 var on=isSeries();
 ["prevEp","nextEp","epListBtn"].forEach(function(id){var b=$(id);if(b)b.classList.toggle("hidden",!on)});
 if(on){$("prevEp").disabled=queueIndex<=0;$("nextEp").disabled=queueIndex>=queue.length-1}
 if(!on)closeEpPanel();
}
function stepEpisode(d){
 if(!isSeries())return false;
 var n=queueIndex+d;
 if(n<0||n>=queue.length){toastMsg(n<0?"هذه أول حلقة":"هذه آخر حلقة");show();return true}
 return playEpisode(n);
}
function playEpisode(n){
 saveResume(true);queueIndex=n;var it=queue[n];
 if(w.onABDOEpisodeStep)try{w.onABDOEpisodeStep(it)}catch(e){}
 closeEpPanel();play(it.name,it.url,serverId,"series");toastMsg("▶ "+it.name);return true;
}
function openEpPanel(){
 if(!isSeries())return;
 var host=$("epPanelList");host.innerHTML="";var lastSeason=null,cur=null;
 queue.forEach(function(it,i){
  if(it.season!==lastSeason){lastSeason=it.season;var h=document.createElement("div");h.className="ep-season";h.textContent=it.season;host.appendChild(h)}
  var b=document.createElement("button");b.type="button";b.className="ep-row"+(i===queueIndex?" current":"");
  b.textContent=(i===queueIndex?"▶ ":"")+(it.label||it.name);
  b.onclick=function(){playEpisode(i)};host.appendChild(b);if(i===queueIndex)cur=b;
 });
 $("epPanel").classList.remove("hidden");navMode=true;show();
 try{if(cur){cur.focus();cur.scrollIntoView({block:"center"})}}catch(e){}
}
function closeEpPanel(){var p=$("epPanel");if(p&&!p.classList.contains("hidden")){p.classList.add("hidden");var l=$("epListBtn");try{if(l&&!l.classList.contains("hidden"))l.focus()}catch(e){}}}

/* ---------- queue / zapping ---------- */
function setQueue(items,index,kind){queue=Array.isArray(items)?items.slice():[];queueIndex=Number.isInteger(index)?index:-1;queueKind=kind||"live";updateEpUi()}
function stepChannel(delta){
 if(queueKind!=="live"||!queue.length)return false;
 var n=queueIndex+delta;if(n<0||n>=queue.length){status(n<0?"أول قناة في القائمة":"آخر قناة في القائمة");show();return true}
 return zapTo(n);
}
function zapTo(n){
 queueIndex=n;var item=queue[n];
 if(w.onABDOChannelStep)try{w.onABDOChannelStep(item)}catch(e){}
 play(item.name,item.url,serverId,"live");banner(item);return true;
}
function numKey(d){
 if(queueKind!=="live"||!queue.length)return false;
 numBuf+=d;clearTimeout(numT);
 var b=$("chanBanner");$("chanNum").textContent=numBuf;$("chanName").textContent="رقم القناة…";$("chanInfo").textContent="";b.classList.remove("hidden");
 numT=setTimeout(function(){
  var want=numBuf;numBuf="";
  for(var i=0;i<queue.length;i++){var r=queue[i].raw;if(r&&String(r.num)===want){zapTo(i);return}}
  $("chanName").textContent="القناة "+want+" غير موجودة في القائمة الحالية";clearTimeout(bannerT);bannerT=setTimeout(function(){b.classList.add("hidden")},2500);
 },1600);
 return true;
}
function keyFor(server,url){var s=String(server||"default")+"|"+String(url||""),h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return "abdo_resume_"+(h>>>0).toString(16)}

/* ---------- play / stop ---------- */
function play(name,url,sid,kind){
 if(!v)init(goBack);
 if(active)saveResume(true);
 if(sid)serverId=sid;if(kind)queueKind=kind;
 active=true;resumeApplied=false;lastPaint=0;navMode=false;
 resumeKey=keyFor(serverId,url);
 $("playingTitle").textContent=name;$("hudTitle").textContent=name;
 $("emptyPlayer").classList.add("hidden");$("settingsMenu").classList.add("hidden");$("playerView").classList.remove("hidden");
 $("chanBanner").classList.add("hidden");
 if($("playerMessage"))$("playerMessage").textContent="OK تشغيل/إيقاف • ◀ ▶ تقديم وتأخير • ▲ ▼ تغيير القناة • الأزرار 0-9 رقم القناة • الأصفر قائمة الحلقات • الأزرق أو INFO لقائمة الأزرار • الأحمر معلومات البث";
 updateEpUi();startWatch();show();
 begin(url);
}
function toggle(){if(v.paused)v.play().then(function(){status("يعمل")}).catch(function(){status("تعذر التشغيل")});else v.pause();show()}
function seek(n){if(isFinite(v.duration)&&v.duration>0&&queueKind!=="live")v.currentTime=Math.max(0,Math.min(v.duration,v.currentTime+n));paint(true);show()}
function seekAccel(sign){
 var now=Date.now();seekCount=(now-lastSeekAt<650)?seekCount+1:0;lastSeekAt=now;
 var steps=[10,10,20,30,60,60,120],st=steps[Math.min(seekCount,steps.length-1)];
 if(queueKind==="live"){status("البث المباشر لا يدعم التقديم");show();return true}
 seek(sign*st);status((sign>0?"تقديم ":"تأخير ")+st+" ثانية");return true;
}
function remote(k){
 if(!active)return false;
 if(k!=="BACK"&&k!=="STOP")show();
 /* menu-navigation mode: the remote moves focus over the on-screen buttons */
 if(navMode){
  if(k==="BACK"&&$("epPanel")&&!$("epPanel").classList.contains("hidden")){closeEpPanel();return true}
  if(k==="BACK"||k==="BLUE"||k==="INFO"){navMode=false;closeEpPanel();$("settingsMenu").classList.add("hidden");try{document.activeElement.blur()}catch(e){}show();return true}
  if(k==="LEFT"||k==="RIGHT"||k==="UP"||k==="DOWN"){if(w.ABDORemote&&ABDORemote.move)ABDORemote.move(k);show();return true}
  if(k==="OK"){var a=document.activeElement;if(a&&a.click)a.click();show();return true}
 }
 if(k==="BACK"||k==="STOP"){stop();return true}
 if(k==="BLUE"||k==="INFO"){navMode=true;show();var f=$("playPause");try{f.focus()}catch(e){}return true}
 if(k==="RED"){toggleStats();return true}
 if(k==="GREEN"){cycleAspect();return true}
 if(k==="YELLOW"&&!isSeries()){tracks();menu("audio");navMode=true;return true}
 if(/^NUM\d$/.test(k))return numKey(k.charAt(3));
 if(k==="OK"||k==="PLAY"){if(v.paused){toggle();enterFullscreen()}else toggle();return true}
 if(k==="PAUSE"){v.pause();show();return true}
 if(k==="LEFT"||k==="REWIND")return seekAccel(-1);
 if(k==="RIGHT"||k==="FAST_FORWARD")return seekAccel(1);
 if(k==="CHANNEL_UP"&&isSeries())return stepEpisode(1);
 if(k==="CHANNEL_DOWN"&&isSeries())return stepEpisode(-1);
 if(k==="YELLOW"&&isSeries()){openEpPanel();return true}
 if(k==="UP"||k==="CHANNEL_UP"){if(queueKind==="live")return stepChannel(1);v.volume=Math.min(1,v.volume+.05);$("volumeBar").value=v.volume;show();return true}
 if(k==="DOWN"||k==="CHANNEL_DOWN"){if(queueKind==="live")return stepChannel(-1);v.volume=Math.max(0,v.volume-.05);$("volumeBar").value=v.volume;show();return true}
 return false;
}
function stop(){
 if(!active)return;
 saveResume(true);active=false;session++;clearTimeout(timer);clearInterval(watch);clearTimeout(bannerT);navMode=false;
 var wrap=$("playerWrap"),settings=$("settingsMenu"),view=$("playerView"),empty=$("emptyPlayer"),done=goBack;
 try{if(document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen().catch(function(){})}catch(e){}
 try{if(v&&typeof v.webkitExitFullscreen==="function")v.webkitExitFullscreen()}catch(e){}
 destroy();spin(false);closeEpPanel();
 try{if(wrap)wrap.classList.remove("abdo-css-fullscreen","hud-visible")}catch(e){}
 try{if(v){v.pause();v.removeAttribute("src");v.load();v.playbackRate=1;rate=0;if($("speedBtn"))$("speedBtn").textContent="السرعة 1x"}}catch(e){}
 try{if($("chanBanner"))$("chanBanner").classList.add("hidden");if(settings)settings.classList.add("hidden");if(view)view.classList.add("hidden");if(empty)empty.classList.remove("hidden")}catch(e){}
 if(typeof done==="function"){try{done()}catch(e){}}
}
w.ABDOPlayer={init:init,play:play,remote:remote,stop:stop,fullscreen:enterFullscreen,setQueue:setQueue,setEngine:setEngine,isActive:function(){return active},engine:function(){return engineName}};
})(window);
