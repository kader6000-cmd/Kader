/* ABDO IPTV — phone link settings.
   ABDO_PHONE_PAGE: full https URL of add.html after you upload it to any static host
                    (GitHub Pages / Netlify / Cloudflare Pages ...). Example: "https://yourname.github.io/abdo/add.html"
   ABDO_RELAY:      message relay (default: public ntfy.sh). */
window.ABDO_PHONE_PAGE="https://kader6000-cmd.github.io/abdo/add.html";
window.ABDO_RELAY="https://ntfy.sh";
