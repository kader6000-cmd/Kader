const $=id=>document.getElementById(id);
const DEFAULT_SERVERS=[{id:'abdo-main-server',name:'السيرفر الرئيسي',type:'xtream',host:'http://tv.nv2.info:80',username:'aos599086',password:'oma422611'}];
const FAV_KEY='abdo_favorites_v1';
const HISTORY_KEY='abdo_watch_history_v1';
const PAGE_SIZE=36;

let servers=ABDOAccounts.list();
if(!servers.length)servers=ABDOAccounts.save(DEFAULT_SERVERS);

let current=null,allItems=[],currentItems=[],groups=[],activeGroup=-1,section='live',favSubTab='live',stack=[],catalogPage=0,pendingDeleteId=null;
let currentSeries=null,currentSeriesData=null,activeSeasonIdx=0;
let currentPlayingObj=null,currentPlayingKind='live';
let selectedToken='',selectedTime=0;

const save=()=>ABDOAccounts.save(servers);

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function toast(t){$('toast').textContent=t;$('toast').style.display='block';clearTimeout(toast._t);toast._t=setTimeout(()=>$('toast').style.display='none',2600)}

function updateClock(){
 const now=new Date();
 const hh=String(now.getHours()).padStart(2,'0');
 const mm=String(now.getMinutes()).padStart(2,'0');
 
}
updateClock();
setInterval(updateClock,20000);

function activateOnDouble(el,token,action,singleHint,posterUrl){
 /* v5.3.1: فتح مباشر بضغطة OK واحدة */
 selectedToken='';selectedTime=0;
 action();return;
 const now=Date.now();
 if(selectedToken===token && (now-selectedTime)<15000 && document.activeElement===el){
  selectedToken='';
  selectedTime=0;
  el.classList.remove('selected-once');
  action();
  return;
 }
 document.querySelectorAll('.selected-once').forEach(node=>node.classList.remove('selected-once'));
 selectedToken=token;
 selectedTime=now;
 el.classList.add('selected-once');
 try{el.focus({preventScroll:true})}catch(e){try{el.focus()}catch(err){}}
 if(singleHint)toast(singleHint);
}

function loadFavStore(){
 try{
  const raw=JSON.parse(localStorage.getItem(FAV_KEY)||'{}');
  return {
   live:Array.isArray(raw.live)?raw.live:[],
   vod:Array.isArray(raw.vod)?raw.vod:[],
   series:Array.isArray(raw.series)?raw.series:[]
  };
 }catch(e){return {live:[],vod:[],series:[]}}
}
function saveFavStore(store){
 try{localStorage.setItem(FAV_KEY,JSON.stringify(store))}catch(e){}
}
function itemUid(x,kind){
 const sid=x._serverId||(current&&current.id)||'default';
 const k=kind||x._kind||section||'live';
 const id=x.series_id||x.stream_id||x.id||x.url||x.name||x.title||'item';
 return `${sid}::${k}::${id}`;
}
function isFav(x,kind){
 if(!x)return false;
 const k=kind||x._kind||section||'live';
 const store=loadFavStore();
 const list=store[k]||[];
 const uid=itemUid(x,k);
 return list.some(it=>it._uid===uid);
}
function toggleFav(x,kind){
 if(!x)return false;
 const k=kind||x._kind||section||'live';
 const store=loadFavStore();
 if(!Array.isArray(store[k]))store[k]=[];
 const uid=itemUid(x,k);
 const idx=store[k].findIndex(it=>it._uid===uid);
 if(idx>=0){
  store[k].splice(idx,1);
  saveFavStore(store);
  toast('تمت الإزالة من المفضلة');
  return false;
 }
 const copy=Object.assign({},x,{
  _uid:uid,
  _kind:k,
  _serverId:x._serverId||(current&&current.id)||'',
  _serverType:x._serverType||(current&&current.type)||'xtream',
  _serverHost:x._serverHost||(current&&current.host)||'',
  _serverUser:x._serverUser||(current&&current.username)||'',
  _serverPass:x._serverPass||(current&&current.password)||'',
  _addedAt:Date.now()
 });
 store[k].unshift(copy);
 saveFavStore(store);
 toast('تمت الإضافة إلى المفضلة ⭐');
 return true;
}

function updatePlayerFavButton(){
 const btn=$('playerFavBtn');
 if(!btn)return;
 if(!currentPlayingObj){
  btn.classList.add('hidden');
  return;
 }
 btn.classList.remove('hidden');
 const favState=isFav(currentPlayingObj,currentPlayingKind);
 btn.classList.toggle('is-fav',favState);
 btn.textContent=favState?'⭐ في المفضلة':'☆ أضف للمفضلة';
}
if($('playerFavBtn')){
 $('playerFavBtn').onclick=e=>{
  e.stopPropagation();
  if(!currentPlayingObj)return;
  toggleFav(currentPlayingObj,currentPlayingKind);
  updatePlayerFavButton();
 };
}

function loadHistoryStore(){
 try{
  const arr=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');
  return Array.isArray(arr)?arr:[];
 }catch(e){return []}
}
function saveHistoryStore(arr){
 try{localStorage.setItem(HISTORY_KEY,JSON.stringify(arr.slice(0,80)))}catch(e){}
}
function recordHistory(x,kind,playUrl,displayName){
 const k=kind||x._kind||section||'live';
 const uid=itemUid(x,k);
 const sid=x._serverId||(current&&current.id)||'';
 const entry=Object.assign({},x,{
  _uid:uid,
  _kind:k,
  _serverId:sid,
  _serverType:x._serverType||(current&&current.type)||'xtream',
  _serverHost:x._serverHost||(current&&current.host)||'',
  _serverUser:x._serverUser||(current&&current.username)||'',
  _serverPass:x._serverPass||(current&&current.password)||'',
  _playUrl:playUrl||x._playUrl||x.url||'',
  name:displayName||x.name||x.title||'بدون اسم',
  _watchedAt:Date.now()
 });
 const list=loadHistoryStore().filter(it=>it._uid!==uid && it._playUrl!==entry._playUrl);
 list.unshift(entry);
 saveHistoryStore(list);
}
function getResumeInfo(serverId,url){
 if(!url)return null;
 try{
  const s=String(serverId||'default')+'|'+String(url||'');
  let h=2166136261;
  for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
  const key='abdo_resume_'+(h>>>0).toString(16);
  const raw=localStorage.getItem(key);
  if(!raw)return null;
  const parsed=JSON.parse(raw);
  if(!parsed||!isFinite(parsed.time)||parsed.time<10)return null;
  return {time:Number(parsed.time),duration:Number(parsed.duration)||0};
 }catch(e){return null}
}
function fmtClock(sec){
 if(!isFinite(sec)||sec<=0)return '';
 const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=Math.floor(sec%60);
 const mm=String(m).padStart(2,'0'),ss=String(s).padStart(2,'0');
 return h>0?`${h}:${mm}:${ss}`:`${mm}:${ss}`;
}

const ALL_VIEWS=['serverView','homeView','catalogView','seriesView','playerView'];
function activeViewName(){
 return ALL_VIEWS.find(x=>!$(x).classList.contains('hidden'))||'serverView';
}
function show(view,push=true){
 const cur=activeViewName();
 if(push&&cur&&cur!==view&&cur!=='playerView')stack.push(cur);
 ALL_VIEWS.forEach(x=>$(x).classList.toggle('hidden',x!==view));
 const inServer=view==='serverView';
 $('backBtn').classList.toggle('hidden',inServer);
 $('homeBtn').classList.toggle('hidden',inServer);
 if($('favHeaderBtn'))$('favHeaderBtn').classList.toggle('hidden',inServer||!current);
 if($('historyHeaderBtn'))$('historyHeaderBtn').classList.toggle('hidden',inServer||!current);
 selectedToken='';
 setTimeout(()=>{
  const el=$(view).querySelector('.selected-once,button:not(:disabled),input,[tabindex="0"]');
  if(el)try{el.focus({preventScroll:true})}catch(e){try{el.focus()}catch(err){}}
 },60);
}
function back(){
 if(window.ABDOUI&&ABDOUI.closeTop()){return}
 if(!$('pickDialog').classList.contains('hidden')){closeServerPicker();return}
 if(!$('deleteDialog').classList.contains('hidden')){closeDeleteDialog();return}
 if(!$('modal').classList.contains('hidden')){$('modal').classList.add('hidden');return}
 if(ABDOPlayer.isActive()){ABDOPlayer.stop();return}
 let v=stack.pop();
 if(!v)v=current?'homeView':'serverView';
 if(v==='playerView')v=currentSeries?'seriesView':'catalogView';
 show(v,false);
 if(v==='serverView')renderServers();
 else if(v==='catalogView'&&(section==='favorites'||section==='history'))loadSpecialSection(section,false);
 else if(v==='catalogView')renderCatalogPage(currentItems);
 else if(v==='seriesView'&&currentSeries&&currentSeriesData)renderSeriesSeasons();
}
$('backBtn').onclick=back;
$('exitBtn').onclick=showExitDialog;
$('homeBtn').onclick=()=>{if(ABDOPlayer.isActive())ABDOPlayer.stop();stack=[];show('serverView',false);renderServers()};

function renderServers(){
 $('count').textContent=`${servers.length} / ${ABDOAccounts.limit}`;
 $('servers').innerHTML='';
 servers.forEach((s,i)=>{
  let el=document.createElement('div');
  el.className='server'+(current&&current.id===s.id?' active':'');
  el.tabIndex=0;
  el.innerHTML=`<span class="num">${i+1}</span><div class="meta"><b></b><small></small></div><div class="actions"><button type="button" class="edit">تعديل</button><button type="button" class="del">حذف</button></div>`;
  el.querySelector('b').textContent=s.name;
  el.querySelector('small').textContent=s.type==='m3u'?'قائمة M3U':'Xtream Codes · '+(s.host||'');
  const token='srv_'+s.id;
  el.onclick=e=>{
   if(e.target.closest('.actions'))return;
   activateOnDouble(el,token,()=>openServer(s),'تم تحديد السيرفر — اضغط مرة أخرى لفتحه','');
  };
  el.onkeydown=e=>{
   if(e.key==='Enter'||e.key===' '){
    if(e.target.closest('.actions'))return;
    e.preventDefault();
    activateOnDouble(el,token,()=>openServer(s),'تم تحديد السيرفر — اضغط OK مرة أخرى لفتحه','');
   }
  };
  el.querySelector('.edit').onclick=e=>{e.stopPropagation();openModal(s)};
  el.querySelector('.del').onclick=e=>{
   e.stopPropagation();
   pendingDeleteId=s.id;
   $('deleteServerName').textContent=s.name;
   $('deleteDialog').classList.remove('hidden');
   $('cancelDeleteBtn').focus();
  };
  $('servers').appendChild(el);
 });
}
function closeDeleteDialog(){pendingDeleteId=null;$('deleteDialog').classList.add('hidden')}
$('cancelDeleteBtn').onclick=closeDeleteDialog;
$('confirmDeleteBtn').onclick=()=>{
 if(!pendingDeleteId){closeDeleteDialog();return}
 let id=pendingDeleteId;
 servers=servers.filter(x=>x.id!==id);cacheClear(id+':');
 if(current&&current.id===id)current=null;
 try{if(localStorage.getItem('abdo_active_server')===id)localStorage.removeItem('abdo_active_server')}catch(e){}
 save();
 closeDeleteDialog();
 renderServers();
 toast('تم حذف السيرفر');
};

window.ABDOCurrentServer=function(){return current||servers[0]||null};
window.ABDOAddServer=function(s){
 try{
  s=ABDOAccounts.normalize(s);
  const same=servers.findIndex(x=>x.type===s.type&&((s.type==='m3u'&&x.url===s.url)||(s.type==='xtream'&&x.host===s.host&&x.username===s.username)));
  if(same>=0){s.id=servers[same].id;servers[same]=s;cacheClear(s.id+':')}
  else{if(servers.length>=100)return{ok:false,msg:'وصلت إلى الحد الأقصى: 100 سيرفر'};servers.push(s)}
  save();renderServers();toast('تمت إضافة السيرفر: '+s.name);
  return{ok:true,server:s};
 }catch(e){return{ok:false,msg:e.message}}
};

function openServer(s){
 current=s;
 try{localStorage.setItem('abdo_active_server',s.id)}catch(e){}
 stack=['serverView'];
 $('serverTitle').textContent=s.name;
 show('homeView',false);
 $('homeStatus').textContent='اختر القسم للمشاهدة';
}

function openModal(s=null){
 $('modal').classList.remove('hidden');
 $('modalTitle').textContent=s?'تعديل السيرفر':'إضافة سيرفر';
 $('serverName').value=s?.name||'';
 $('serverType').value=s?.type||'xtream';
 $('m3uUrl').value=s?.url||'';
 $('host').value=s?.host||'';
 $('username').value=s?.username||'';
 $('password').value=s?.password||'';
 $('formError').textContent='';
 $('saveBtn').dataset.edit=s?.id||'';
 toggleFields();
 $('serverName').focus();
}
function toggleFields(){
 let m=$('serverType').value==='m3u';
 $('m3uFields').classList.toggle('hidden',!m);
 $('xtreamFields').classList.toggle('hidden',m);
}
$('addBtn').onclick=()=>{if(servers.length>=100){toast('وصلت إلى الحد الأقصى: 100 سيرفر');return}openModal()};
$('closeModal').onclick=()=>$('modal').classList.add('hidden');
$('serverType').onchange=toggleFields;

$('saveBtn').onclick=()=>{
 let type=$('serverType').value,name=$('serverName').value.trim();
 if(!name){$('formError').textContent='اكتب اسم السيرفر';return}
 let s={id:$('saveBtn').dataset.edit||String(Date.now()),name,type};
 if(type==='m3u'){
  s.url=$('m3uUrl').value.trim();
  if(!/^https?:\/\//i.test(s.url)){$('formError').textContent='أدخل رابط M3U صحيحًا';return}
  try{
   let u=new URL(s.url),un=u.searchParams.get('username'),pw=u.searchParams.get('password');
   if(/get\.php$/i.test(u.pathname)&&un&&pw){s.type='xtream';s.host=u.origin;s.username=un;s.password=pw;}
  }catch(e){}
 }else{
  s.host=$('host').value.trim().replace(/\/+$/,'');
  s.username=$('username').value.trim();
  s.password=$('password').value;
  if(!/^https?:\/\//i.test(s.host)||!s.username||!s.password){$('formError').textContent='أكمل عنوان السيرفر واسم المستخدم وكلمة المرور';return}
 }
 let i=servers.findIndex(x=>x.id===s.id);
 if(i>=0)servers[i]=s;
 else if(servers.length<100)servers.push(s);
 else{$('formError').textContent='يمكن حفظ 100 سيرفر كحد أقصى';return}
 save();cacheClear(s.id+':');
 $('modal').classList.add('hidden');
 renderServers();
 openServer(s);
};

/* تفعيل ربط أزرار القالب السينمائي الرئيسي ومعالجة النقرة المفردة والمزدوجة بالريموت */
document.querySelectorAll('.cine-card, .sub-cine-btn').forEach(b=>{
 b.onclick=e=>{
  e.preventDefault();
  const cat=b.dataset.cat;
  const action=b.dataset.action;
  activateOnDouble(b,'cine_'+(cat||action),()=>{
   if(cat==='favorites'||cat==='history')loadSpecialSection(cat,true);
   else if(cat)loadSection(cat);
   else if(action==='about'){if(window.ABDOUI)ABDOUI.openInfo();}
   else if(action==='refresh')refreshContent();
   else if(action==='servers')openServerPicker();
   else if(action==='search'){loadSection('vod');setTimeout(()=>$('search').focus(),100);}
  },'اضغط مرة أخرى للتأكيد','');
 };
});

document.querySelectorAll('.fav-tab').forEach(tab=>{
 tab.onclick=()=>{
  favSubTab=tab.dataset.favtab||'live';
  document.querySelectorAll('.fav-tab').forEach(t=>t.classList.toggle('active',t===tab));
  loadSpecialSection('favorites',false);
 };
});

$('clearHistoryBtn').onclick=()=>{
 saveHistoryStore([]);
 loadSpecialSection('history',false);
 toast('تم مسح سجل المشاهدات');
};


/* ---------- v5.3: ذاكرة مؤقتة للأقسام (تسريع الفتح) + تحديث حقيقي ---------- */
const CACHE_TTL=30*60*1000,CACHE_MAX=3,secCache=new Map();
function cacheGet(k){const e=secCache.get(k);if(!e)return null;if(Date.now()-e.t>CACHE_TTL){secCache.delete(k);return null}secCache.delete(k);secCache.set(k,e);return e.v}
function cacheSet(k,v){secCache.delete(k);secCache.set(k,{t:Date.now(),v});while(secCache.size>CACHE_MAX)secCache.delete(secCache.keys().next().value)}
function cacheClear(prefix){Array.from(secCache.keys()).forEach(k=>{if(!prefix||k.indexOf(prefix)===0)secCache.delete(k)})}
function fetchSection(srv,cat,force){
 const key=srv.id+':'+(srv.type==='xtream'?cat:'m3u');
 if(!force){const c=cacheGet(key);if(c)return Promise.resolve(c)}
 const p=srv.type==='xtream'?ABDOSource.xtream(srv,cat):ABDOSource.m3u(srv.url);
 return p.then(r=>{cacheSet(key,r);return r});
}
let refreshing=false;
async function refreshContent(){
 if(!current||refreshing)return;
 refreshing=true;
 const btn=document.querySelector('[data-action="refresh"]'),label=btn&&btn.querySelector('b'),old=label?label.textContent:'';
 if(btn)btn.classList.add('is-busy');
 if(label)label.textContent='جارٍ التحديث…';
 $('homeStatus').textContent='جارٍ تحديث المحتوى…';
 cacheClear(current.id+':');
 try{
  const r=await fetchSection(current,'live',true);
  const n=current.type==='xtream'?r.items.length:r.items.filter(x=>x.kind==='live').length;
  toast('تم تحديث المحتوى — '+n+' قناة مباشرة');
 }catch(e){
  toast('تعذر التحديث: '+(e&&e.message?e.message:'تحقق من الاتصال'));
 }finally{
  refreshing=false;
  if(btn)btn.classList.remove('is-busy');
  if(label)label.textContent=old||'تحديث المحتوى';
  $('homeStatus').textContent='اختر القسم للمشاهدة';
 }
}

/* ---------- v5.3: اختيار السيرفر من الشاشة الرئيسية ---------- */
function closeServerPicker(){
 $('pickDialog').classList.add('hidden');
 const b=document.querySelector('[data-action="servers"]');if(b)try{b.focus()}catch(e){}
}
function openServerPicker(){
 const list=$('pickList');list.innerHTML='';
 servers.forEach((s,i)=>{
  const b=document.createElement('button');b.type='button';
  b.className='pick-item'+(current&&current.id===s.id?' active':'');
  const num=document.createElement('span');num.className='pick-num';num.textContent=String(i+1);
  const nm=document.createElement('b');nm.textContent=s.name||('سيرفر '+(i+1));
  const tp=document.createElement('small');tp.textContent=s.type==='m3u'?'M3U':'Xtream';
  b.appendChild(num);b.appendChild(nm);b.appendChild(tp);
  b.onclick=()=>{
   closeServerPicker();
   if(current&&current.id===s.id){toast('هذا هو السيرفر الحالي');return}
   openServer(s);toast('تم التبديل إلى: '+(s.name||'السيرفر'));
  };
  list.appendChild(b);
 });
 $('pickDialog').classList.remove('hidden');
 setTimeout(()=>{const t=list.querySelector('.active')||list.querySelector('button');if(t)try{t.focus()}catch(e){}},50);
}
$('closePick').onclick=closeServerPicker;
$('pickDone').onclick=closeServerPicker;
$('pickManage').onclick=()=>{closeServerPicker();$('homeBtn').click()};
$('pickDialog').addEventListener('click',e=>{if(e.target===$('pickDialog'))closeServerPicker()});

function loadSpecialSection(cat,pushView=true){
 currentSeries=null;
 section=cat;
 activeGroup=-1;
 $('search').value='';
 $('favTabs').classList.toggle('hidden',cat!=='favorites');
 $('clearHistoryBtn').classList.toggle('hidden',cat!=='history');
 $('groups').classList.add('hidden');
 $('catalogLayout').classList.add('no-sidebar');
 if(pushView)show('catalogView');
 if(cat==='favorites'){
  const titles={live:'⭐ المفضلة · القنوات',vod:'⭐ المفضلة · الأفلام',series:'⭐ المفضلة · المسلسلات'};
  $('catalogTitle').textContent=titles[favSubTab]||'⭐ المفضلة';
  const store=loadFavStore();
  allItems=(store[favSubTab]||[]).map(it=>Object.assign({},it,{_kind:favSubTab}));
  $('catalogStatus').textContent=`${allItems.length} عنصر مفضل`;
  filterItems();
 }else if(cat==='history'){
  $('catalogTitle').textContent='🕘 آخر المشاهدات واستكمال التشغيل';
  allItems=loadHistoryStore();
  $('catalogStatus').textContent=`${allItems.length} عنصر في السجل`;
  filterItems();
 }
}

async function loadSection(cat){
 currentSeries=null;
 section=cat;
 activeGroup=-1;
 $('favTabs').classList.add('hidden');
 $('clearHistoryBtn').classList.add('hidden');
 $('groups').classList.remove('hidden');
 $('catalogLayout').classList.remove('no-sidebar');
 $('catalogTitle').textContent={live:'📺 البث المباشر',vod:'🎬 الأفلام',series:'📚 المسلسلات'}[cat]||'المحتوى';
 $('catalogStatus').textContent='تحميل...';
 $('groups').innerHTML='';
 $('items').innerHTML='';
 $('search').value='';
 show('catalogView');

 try{
  if(current.type==='xtream'){
   let result=await fetchSection(current,cat);
   groups=result.groups;
   allItems=result.items.map(it=>Object.assign({},it,{_kind:cat,_serverId:current.id}));
   renderGroups();
   filterItems();
   $('catalogStatus').textContent=`${allItems.length} عنصر`;
  }else{
   let result=await fetchSection(current,cat);
   allItems=result.items;
   let relevant=cat==='live'?allItems.filter(x=>x.kind==='live'):cat==='vod'?allItems.filter(x=>x.kind==='vod'):allItems.filter(x=>/series|episode|مسلسل|حلقة/i.test((x.group||'')+' '+(x.name||'')));
   groups=result.groups.filter(g=>relevant.some(x=>x.group===g.category_name));
   allItems=relevant.map(it=>Object.assign({},it,{_kind:cat,_serverId:current.id}));
   renderGroups();
   filterItems();
   $('catalogStatus').textContent=`${allItems.length} عنصر`;
  }
 }catch(e){
  $('catalogStatus').textContent='خطأ';
  $('items').innerHTML=`<div class="empty-list">تعذر تحميل القسم: ${esc(e.message)}<br>تحقق من بيانات السيرفر واتصال الشبكة.</div>`;
 }
}

function renderGroups(){
 const frag=document.createDocumentFragment();
 let allBtn=document.createElement('button');
 allBtn.className='group'+(activeGroup===-1?' active':'');
 allBtn.textContent='كل المجموعات ('+allItems.length+')';
 allBtn.onclick=()=>{activeGroup=-1;renderGroups();filterItems()};
 frag.appendChild(allBtn);
 groups.forEach((g,i)=>{
  let b=document.createElement('button');
  b.className='group'+(activeGroup===i?' active':'');
  b.textContent=g.category_name||g.name||'قسم';
  b.onclick=()=>{activeGroup=i;renderGroups();filterItems()};
  frag.appendChild(b);
 });
 $('groups').innerHTML='';
 $('groups').appendChild(frag);
}

function serverForItem(x){
 if(x&&x._serverHost)return {id:x._serverId||'saved',type:x._serverType||'xtream',host:x._serverHost,username:x._serverUser,password:x._serverPass};
 return current||servers[0]||{};
}

function streamUrlFor(x,kind){
 if(x._playUrl)return x._playUrl;
 if(x.url)return x.url;
 const srv=serverForItem(x);
 if(srv&&srv.type==='xtream')return ABDOSource.stream(srv,x,kind);
 return '';
}

function posterOf(x){
 let raw=x.stream_icon||x.cover||x.cover_big||x.movie_image||x.icon||x.poster||x.logo||x['tvg-logo']||'';
 if(!raw||typeof raw!=='string')return '';
 raw=raw.trim();
 if(!raw||/^(null|undefined|false)$/i.test(raw))return '';
 const srv=serverForItem(x);
 try{return new URL(raw,srv&&srv.host?srv.host:srv&&srv.url?srv.url:location.href).href}catch(e){return raw}
}

function effectiveKind(x){
 if(section==='favorites')return favSubTab;
 if(section==='history')return x._kind||'vod';
 return x._kind||section||'live';
}

function renderCatalogPage(arr){
 let host=$('items');
 host.innerHTML='';
 host.scrollTop=0;
 let total=Math.max(1,Math.ceil(arr.length/PAGE_SIZE));
 catalogPage=Math.max(0,Math.min(catalogPage,total-1));
 let start=catalogPage*PAGE_SIZE;
 const frag=document.createDocumentFragment();

 arr.slice(start,start+PAGE_SIZE).forEach((x,idx)=>{
  const k=effectiveKind(x);
  const uid=itemUid(x,k);
  const wrap=document.createElement('div');
  wrap.className='card-wrap';

  const star=document.createElement('button');
  star.type='button';
  const favState=isFav(x,k);
  star.className='fav-star'+(favState?' is-fav':'');
  star.textContent=favState?'⭐':'☆';
  star.onclick=e=>{
   e.stopPropagation();
   const nowFav=toggleFav(x,k);
   star.className='fav-star'+(nowFav?' is-fav':'');
   star.textContent=nowFav?'⭐':'☆';
   if(section==='favorites')loadSpecialSection('favorites',false);
  };
  wrap.appendChild(star);

  const b=document.createElement('button');
  b.type='button';
  b.className='item item-card';
  let src=posterOf(x);
  if(src){
   let im=document.createElement('img');
   im.className='item-poster';
   im.alt='';
   im.loading='lazy';
   im.src=src;
   im.onerror=function(){
    this.remove();
    let ph=document.createElement('div');
    ph.className='item-poster item-placeholder';
    ph.textContent=k==='series'?'مسلسل':k==='vod'?'فيلم':'قناة';
    b.insertBefore(ph,b.firstChild);
   };
   b.appendChild(im);
  }else{
   let ph=document.createElement('div');
   ph.className='item-poster item-placeholder';
   ph.textContent=k==='series'?'مسلسل':k==='vod'?'فيلم':'قناة';
   b.appendChild(ph);
  }

  if(k!=='live'){
   const testUrl=streamUrlFor(x,k);
   const srv=serverForItem(x);
   const res=getResumeInfo(srv.id,testUrl);
   if(res){
    const badge=document.createElement('span');
    badge.className='resume-badge';
    badge.textContent='استكمال '+fmtClock(res.time);
    wrap.appendChild(badge);
   }
  }

  let title=document.createElement('span');
  title.className='item-title';
  title.textContent=x.name||x.title||'بدون اسم';
  b.appendChild(title);

  b.onclick=()=>activateOnDouble(
   b,
   'item_'+uid+'_'+idx,
   ()=>chooseItem(x,k),
   k==='series'&&!x._isEpisode?'تم تحديد المسلسل — اضغط مرة أخرى لعرض الحلقات':'تم تحديد العنصر — اضغط مرة أخرى للتشغيل',
   src
  );
  wrap.appendChild(b);
  frag.appendChild(wrap);
 });

 host.appendChild(frag);

 if(!arr.length){
  host.innerHTML='<div class="empty-list">لا توجد عناصر في هذا القسم</div>';
 }
 let pages=$('itemPages');
 pages.innerHTML='';
 if(arr.length>PAGE_SIZE){
  let prev=document.createElement('button');
  prev.textContent='السابق';
  prev.disabled=catalogPage===0;
  prev.onclick=()=>{catalogPage--;renderCatalogPage(arr)};
  let label=document.createElement('span');
  label.textContent='صفحة '+(catalogPage+1)+' من '+total+' · '+arr.length+' عنصر';
  let next=document.createElement('button');
  next.textContent='التالي';
  next.disabled=catalogPage>=total-1;
  next.onclick=()=>{catalogPage++;renderCatalogPage(arr)};
  pages.append(prev,label,next);
 }
}

function filterItems(){
 let q=$('search').value.toLowerCase().trim();
 const isMedia=(section==='vod'||section==='series'||(section==='favorites'&&favSubTab!=='live')||section==='history');
 $('items').classList.toggle('media-catalog',isMedia);
 let selected=(activeGroup<0||section==='favorites'||section==='history')?allItems:allItems.filter(x=>String(x.category_id??'')===String(groups[activeGroup]?.category_id??'')||String(x.group||'')===String(groups[activeGroup]?.category_name||''));
 let arr=q?selected.filter(x=>String(x.name||x.title||'').toLowerCase().includes(q)):selected;
 catalogPage=0;
 currentItems=arr;
 renderCatalogPage(arr);
}
let _searchT;$('search').oninput=()=>{clearTimeout(_searchT);_searchT=setTimeout(filterItems,250)};

function chooseItem(x,forcedKind){
 const k=forcedKind||effectiveKind(x);
 const srv=serverForItem(x);
 if(k==='series' && !x._isEpisode && srv.type==='xtream' && x.series_id){
  openSeriesPage(x,srv);
  return;
 }
 let selectedName=x.name||x.title||'بدون اسم';
 if(k==='live'){
  let rawIdx=currentItems.indexOf(x);
  if(rawIdx<0)rawIdx=0;
  let startSlice=Math.max(0,rawIdx-30),endSlice=Math.min(currentItems.length,rawIdx+30);
  let slice=currentItems.slice(startSlice,endSlice);
  let list=slice.map(it=>({
   name:it.name||it.title||'بدون اسم',
   url:streamUrlFor(it,'live'),
   kind:'live',
   raw:it
  })).filter(it=>!!it.url);
  let idx=list.findIndex(it=>it.raw===x||it.name===selectedName);
  ABDOPlayer.setQueue(list,idx,'live');
 }else{
  ABDOPlayer.setQueue([],-1,k);
 }
 let url=streamUrlFor(x,k);
 if(url){
  currentPlayingObj=x;
  currentPlayingKind=k;
  updatePlayerFavButton();
  recordHistory(x,k,url,selectedName);
  playItem(selectedName,url,k,srv.id);
 }else toast('لا يوجد رابط تشغيل لهذا العنصر');
}

async function openSeriesPage(x,srv){
 currentSeries=Object.assign({},x,{_serverId:srv.id,_serverType:srv.type,_serverHost:srv.host,_serverUser:srv.username,_serverPass:srv.password});
 currentSeriesData=null;
 activeSeasonIdx=0;
 $('seriesTitle').textContent=x.name||x.title||'المسلسل';
 $('seriesMeta').textContent='نقرة واحدة لتحديد الحلقة · نقرتان للتشغيل';
 $('seriesStatus').textContent='جارٍ تحميل المواسم والحلقات...';
 $('seasonsList').innerHTML='';
 $('episodesList').innerHTML='';
 updateSeriesFavBtn();
 show('seriesView');
 try{
  const d=await ABDOSource.seriesInfo(srv,x.series_id);
  currentSeriesData=normalizeSeriesData(d);
  renderSeriesSeasons();
 }catch(e){
  $('seriesStatus').textContent='تعذر تحميل الحلقات';
  $('episodesList').innerHTML=`<div class="empty-list">تعذر تحميل حلقات المسلسل: ${esc(e.message)}</div>`;
 }
}

function updateSeriesFavBtn(){
 if(!currentSeries)return;
 const fav=isFav(currentSeries,'series');
 $('seriesFavBtn').textContent=fav?'⭐ في المفضلة (إزالة)':'☆ إضافة للمفضلة';
}
$('seriesFavBtn').onclick=()=>{
 if(!currentSeries)return;
 toggleFav(currentSeries,'series');
 updateSeriesFavBtn();
};

function normalizeSeriesData(d){
 const rawSeasons=Array.isArray(d.seasons)?d.seasons:[];
 const rawEps=d.episodes||{};
 const result=[];
 if(Array.isArray(rawEps)){
  const bySeason={};
  rawEps.forEach(ep=>{
   const sn=String(ep.season_number||ep.season||1);
   if(!bySeason[sn])bySeason[sn]=[];
   bySeason[sn].push(ep);
  });
  Object.keys(bySeason).forEach(sn=>{
   result.push({name:'الموسم '+sn,season_number:sn,episodes:bySeason[sn]});
  });
 }else if(rawEps && typeof rawEps==='object'){
  const keys=Object.keys(rawEps);
  keys.forEach(sn=>{
   const list=rawEps[sn]||[];
   if(!list.length)return;
   const match=rawSeasons.find(s=>String(s.season_number)===String(sn));
   result.push({
    name:(match&&match.name)?match.name:('الموسم '+sn),
    season_number:sn,
    episodes:list
   });
  });
 }
 return result;
}

function renderSeriesSeasons(){
 const seasons=currentSeriesData||[];
 $('seasonsList').innerHTML='';
 $('episodesList').innerHTML='';
 if(!seasons.length){
  $('seriesStatus').textContent='لا توجد حلقات متاحة';
  $('episodesList').innerHTML='<div class="empty-list">لم يتم العثور على مواسم أو حلقات لهذا المسلسل</div>';
  return;
 }
 activeSeasonIdx=Math.max(0,Math.min(activeSeasonIdx,seasons.length-1));
 let totalEps=0;
 const sFrag=document.createDocumentFragment();
 seasons.forEach((s,idx)=>{
  totalEps+=(s.episodes||[]).length;
  const b=document.createElement('button');
  b.type='button';
  b.className='group'+(idx===activeSeasonIdx?' active':'');
  b.textContent=`${s.name} (${(s.episodes||[]).length} حلقة)`;
  b.onclick=()=>{activeSeasonIdx=idx;renderSeriesSeasons()};
  sFrag.appendChild(b);
 });
 $('seasonsList').appendChild(sFrag);
 $('seriesStatus').textContent=`${seasons.length} مواسم · ${totalEps} حلقة`;
 const activeSeason=seasons[activeSeasonIdx];
 const srv=serverForItem(currentSeries);
 const epFrag=document.createDocumentFragment();

 (activeSeason.episodes||[]).forEach((ep,i)=>{
  const epTitle=ep.title||(`الحلقة ${ep.episode_num||i+1}`);
  const fullTitle=`${currentSeries.name||'مسلسل'} - ${activeSeason.name} - ${epTitle}`;
  const playUrl=ABDOSource.stream(srv,{stream_id:ep.id,container_extension:ep.container_extension},'series');
  const res=getResumeInfo(srv.id,playUrl);

  const btn=document.createElement('button');
  btn.type='button';
  btn.className='item episode-card';
  const nameSpan=document.createElement('span');
  nameSpan.className='ep-name';
  nameSpan.textContent=`${ep.episode_num||i+1}. ${epTitle}`;
  const metaSpan=document.createElement('span');
  metaSpan.className='ep-meta';
  metaSpan.textContent=res?`▶ استكمال (${fmtClock(res.time)})`:'▶ تشغيل';
  btn.append(nameSpan,metaSpan);

  const epToken=`ep_${currentSeries.series_id}_${activeSeason.season_number}_${ep.id||i}`;
  btn.onclick=()=>activateOnDouble(btn,epToken,()=>{
   const epRecord=Object.assign({},currentSeries,{
    id:'ep_'+ep.id,
    stream_id:ep.id,
    name:fullTitle,
    _isEpisode:true,
    _playUrl:playUrl,
    _kind:'series'
   });
   currentPlayingObj=currentSeries;
   currentPlayingKind='series';
   updatePlayerFavButton();
   recordHistory(epRecord,'series',playUrl,fullTitle);
   const q=buildEpisodeQueue(seasons,srv),qi=q.findIndex(x=>x.url===playUrl);
   ABDOPlayer.setQueue(q,qi<0?0:qi,'series');
   playItem(fullTitle,playUrl,'series',srv.id);
  },'تم تحديد الحلقة — اضغط مرة أخرى للتشغيل',posterOf(currentSeries));
  if(window.AndroidDL){
   const row=document.createElement('div');row.className='ep-row';
   btn.style.flex='1';
   const dl=document.createElement('button');dl.type='button';dl.className='item ep-dl';dl.textContent='⬇ تحميل';
   dl.onclick=(e)=>{e.stopPropagation();const r=window.AndroidDL.download(playUrl,fullTitle,ep.container_extension||'mp4');toast(r==='ok'?'بدأ التحميل: '+epTitle:'تعذر بدء التحميل')};
   row.append(btn,dl);epFrag.appendChild(row);
  }else epFrag.appendChild(btn);
 });
 if(window.AndroidDL){
  const all=document.createElement('button');all.type='button';all.className='item ep-dl-all';
  all.textContent='⬇ تحميل كل حلقات '+activeSeason.name+' ('+(activeSeason.episodes||[]).length+')';
  all.style.gridColumn='1 / -1';
  all.onclick=()=>{
   if(!confirm('تحميل '+(activeSeason.episodes||[]).length+' حلقة؟ قد يستهلك مساحة وباقة إنترنت كبيرة.'))return;
   const list=(activeSeason.episodes||[]).map((ep,i)=>({url:ABDOSource.stream(srv,{stream_id:ep.id,container_extension:ep.container_extension},'series'),name:`${currentSeries.name||'مسلسل'} - ${activeSeason.name} - ${ep.title||('الحلقة '+(ep.episode_num||i+1))}`,ext:ep.container_extension||'mp4'}));
   window.AndroidDL.downloadMany(JSON.stringify(list));toast('أُضيفت '+list.length+' حلقة لقائمة التحميل');
  };
  epFrag.insertBefore(all,epFrag.firstChild);
 }
 $('episodesList').appendChild(epFrag);
}

function buildEpisodeQueue(seasons,srv){
 const out=[];
 (seasons||[]).forEach(se=>{
  (se.episodes||[]).forEach((ep,i)=>{
   const epTitle=ep.title||(`الحلقة ${ep.episode_num||i+1}`);
   const url=ABDOSource.stream(srv,{stream_id:ep.id,container_extension:ep.container_extension},'series');
   out.push({name:`${currentSeries.name||'مسلسل'} - ${se.name} - ${epTitle}`,url,kind:'series',season:se.name,label:`${ep.episode_num||i+1}. ${epTitle}`,raw:{ep,seasonName:se.name,epTitle}});
  });
 });
 return out;
}
window.onABDOEpisodeStep=function(item){
 try{
  const srv=current||servers[0];
  currentPlayingObj=currentSeries;currentPlayingKind='series';updatePlayerFavButton();
  recordHistory(Object.assign({},currentSeries,{id:'ep_'+item.raw.ep.id,stream_id:item.raw.ep.id,name:item.name,_isEpisode:true,_playUrl:item.url,_kind:'series'}),'series',item.url,item.name);
 }catch(e){}
};

function playItem(name,url,kind,sid){
 show('playerView');
 ABDOPlayer.play(name,url,sid||(current&&current.id),kind||section);
}

window.onABDOChannelStep=function(item){
 if(item&&item.raw){
  currentPlayingObj=item.raw;
  currentPlayingKind='live';
  updatePlayerFavButton();
  recordHistory(item.raw,'live',item.url,item.name);
 }
};

ABDOPlayer.init(back);
ABDOMediaRemoteInit();

$('testServerBtn').onclick=async()=>{
 let s=current||servers[0];
 if(!s){toast('لا يوجد سيرفر محفوظ');return}
 toast('جارٍ اختبار الاتصال…');
 try{
  if(s.type==='xtream'){
   let d=await ABDOSource.json(ABDOSource.endpoint(s,''));
   if(!(d.user_info||d.server_info))throw Error('استجابة غير متوقعة من Xtream');
  }else{
   let d=await ABDOSource.get(s.url);
   if(!d.includes('#EXTM3U'))throw Error('الرد ليس قائمة M3U');
  }
  toast('السيرفر متصل ويعمل بنجاح ✅');
 }catch(e){toast('فشل الاتصال: '+e.message)}
};

function showExitDialog(){
 const d=$('exitDialog');if(!d)return;
 d.classList.remove('hidden');
 $('stayBtn').focus();
}
function hideExitDialog(){$('exitDialog').classList.add('hidden')}
$('stayBtn').onclick=hideExitDialog;
$('confirmExitBtn').onclick=()=>{
 hideExitDialog();
 try{
  if(window.webOS&&webOS.platformBack){webOS.platformBack();return}
  if(window.PalmSystem&&PalmSystem.close){PalmSystem.close();return}
 }catch(e){}
 try{window.close()}catch(e){}
 toast('إذا لم يغلق التطبيق، استخدم زر HOME في ريموت الشاشة.');
};
$('exitDialog').addEventListener('click',e=>{if(e.target===$('exitDialog'))hideExitDialog()});

function ABDOMediaRemoteInit(){
 ABDORemote.bind(function(k){
  if(!$('exitDialog').classList.contains('hidden')){
   if(k==='BACK'){hideExitDialog();return}
   if(k==='LEFT'||k==='RIGHT'){
    let a=document.activeElement;
    if(a&&a.id==='stayBtn')$('confirmExitBtn').focus();
    else $('stayBtn').focus();
    return;
   }
   if(k==='OK'){let a=document.activeElement;if(a&&a.click)a.click();return}
   return;
  }
  if(window.ABDOUI&&ABDOUI.anyOpen()){if(k==='BACK'||k==='BACK_DOUBLE')ABDOUI.closeTop();return}
  if(k==='BACK_DOUBLE'){showExitDialog();return}
  if(ABDOPlayer.isActive()){ABDOPlayer.remote(k);return}
  if(k==='BACK'){
   if(!$('serverView').classList.contains('hidden'))toast('اضغط رجوع مرة أخرى خلال ثانيتين للخروج');
   else back();
   return;
  }
  if(k==='OK'){
   let a=document.activeElement;
   if(a&&a.click)a.click();
  }
 },function(){return ABDOPlayer.isActive()});
}

renderServers();
(function restoreLastServer(){
 try{
  var id=localStorage.getItem('abdo_active_server');
  var saved=servers.find(function(x){return x.id===id});
  if(saved){
   current=saved;
   $('serverTitle').textContent=saved.name;
   stack=['serverView'];
   show('homeView',false);
   $('homeStatus').textContent='تم استعادة آخر سيرفر مستخدم';
  }
 }catch(e){}
})();


/* === ABDO IPTV v4.2.5 Additions: Scroll Handlers & Color Theme Switcher === */
(function(){
  const THEME_STORAGE_KEY = 'abdo_color_theme_v425';
  const THEMES = [
    { id: '', name: 'الأحمر السينمائي (الافتراضي)' },
    { id: 'theme-blue', name: 'الأزرق الملكي' },
    { id: 'theme-emerald', name: 'الأخضر الزمردي' },
    { id: 'theme-purple', name: 'البنفسجي الفاخر' },
    { id: 'theme-gold', name: 'الذهبي الداكن' }
  ];

  function applyColorTheme(themeId, notify) {
    THEMES.forEach(t => { if (t.id) document.body.classList.remove(t.id); });
    const found = THEMES.find(t => t.id === themeId) || THEMES[0];
    if (found.id) document.body.classList.add(found.id);
    try { localStorage.setItem(THEME_STORAGE_KEY, found.id); } catch(e) {}
    if ($('themeBtn')) $('themeBtn').textContent = '🎨 ' + found.name.split(' ')[0];
    if (notify) toast('تم تغيير لون البرنامج إلى: ' + found.name);
  }

  function cycleColorTheme() {
    let cur = '';
    try { cur = localStorage.getItem(THEME_STORAGE_KEY) || ''; } catch(e) {}
    const idx = THEMES.findIndex(t => t.id === cur);
    const next = THEMES[(idx + 1) % THEMES.length];
    applyColorTheme(next.id, true);
  }

  try {
    const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) || '';
    applyColorTheme(savedTheme, false);
  } catch(e) {}

  if ($('themeBtn')) $('themeBtn').onclick = cycleColorTheme;
  if ($('settingsBtn')) $('settingsBtn').onclick = cycleColorTheme;

  function scrollCurrentList(delta) {
    const pane = document.querySelector('.view:not(.hidden) #items, .view:not(.hidden) #episodesList, .view:not(.hidden) #servers');
    if (pane) pane.scrollTop += delta;
  }

  if ($('scrollUpBtn')) $('scrollUpBtn').onclick = () => scrollCurrentList(-360);
  if ($('scrollDownBtn')) $('scrollDownBtn').onclick = () => scrollCurrentList(360);
  if ($('epScrollUpBtn')) $('epScrollUpBtn').onclick = () => scrollCurrentList(-360);
  if ($('epScrollDownBtn')) $('epScrollDownBtn').onclick = () => scrollCurrentList(360);

  document.addEventListener('wheel', function(e) {
    if (window.ABDOPlayer && ABDOPlayer.isActive()) return;
    const pane = e.target.closest('.scrollable-pane, #items, #groups, #episodesList, #seasonsList, #servers') ||
                 document.querySelector('.view:not(.hidden) #items, .view:not(.hidden) #episodesList');
    if (pane) pane.scrollTop += e.deltaY;
  }, { passive: true });
})();
