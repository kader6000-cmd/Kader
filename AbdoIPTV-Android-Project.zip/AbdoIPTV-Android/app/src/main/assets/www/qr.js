/* Minimal offline QR Code generator (byte mode, ECC level M, versions 1-10). ABDOQR.draw(canvas,text,px) */
(function(w){"use strict";
var ECC=[-1,10,16,26,18,24,16,18,22,22,26],BLK=[-1,1,1,1,2,2,4,4,4,5,5];
function rawModules(v){var r=(16*v+128)*v+64;if(v>=2){var n=Math.floor(v/7)+2;r-=(25*n-10)*n-55;if(v>=7)r-=36}return r}
function mul(x,y){var z=0;for(var i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x}return z}
function divisor(d){var r=[],i,j;for(i=0;i<d-1;i++)r.push(0);r.push(1);var root=1;for(i=0;i<d;i++){for(j=0;j<d;j++){r[j]=mul(r[j],root);if(j+1<d)r[j]^=r[j+1]}root=mul(root,2)}return r}
function remainder(data,div){var r=div.map(function(){return 0});data.forEach(function(b){var f=b^r.shift();r.push(0);div.forEach(function(c,i){r[i]^=mul(c,f)})});return r}
function utf8(s){var o=[];s=unescape(encodeURIComponent(s));for(var i=0;i<s.length;i++)o.push(s.charCodeAt(i));return o}
function encode(text){
 var bytes=utf8(text),ver,cap;
 for(ver=1;ver<=10;ver++){cap=Math.floor(rawModules(ver)/8)-ECC[ver]*BLK[ver];var cc=ver<10?8:16;if(4+cc+bytes.length*8<=cap*8)break}
 if(ver>10)throw Error("QR text too long");
 var bits=[];function put(v,n){for(var i=n-1;i>=0;i--)bits.push((v>>>i)&1)}
 put(4,4);put(bytes.length,ver<10?8:16);bytes.forEach(function(b){put(b,8)});
 put(0,Math.min(4,cap*8-bits.length));put(0,(8-bits.length%8)%8);
 for(var pad=0xEC;bits.length<cap*8;pad^=0xEC^0x11)put(pad,8);
 var data=[];for(var i=0;i<bits.length;i+=8){var b=0;for(var j=0;j<8;j++)b=(b<<1)|bits[i+j];data.push(b)}
 /* ECC + interleave */
 var nb=BLK[ver],el=ECC[ver],raw=Math.floor(rawModules(ver)/8),ns=nb-raw%nb,sl=Math.floor(raw/nb),blocks=[],div=divisor(el),k=0;
 for(i=0;i<nb;i++){var dat=data.slice(k,k+sl-el+(i<ns?0:1));k+=dat.length;var ecc=remainder(dat,div);if(i<ns)dat.push(0);blocks.push(dat.concat(ecc))}
 var all=[];for(i=0;i<blocks[0].length;i++)blocks.forEach(function(bl,j){if(i!==sl-el||j>=ns)all.push(bl[i])});
 return {ver:ver,codewords:all};
}
function build(text){
 var e=encode(text),ver=e.ver,size=ver*4+17,m=[],f=[],x,y;
 for(y=0;y<size;y++){m.push(new Array(size).fill(false));f.push(new Array(size).fill(false))}
 function set(x,y,d){if(x>=0&&x<size&&y>=0&&y<size){m[y][x]=!!d;f[y][x]=true}}
 for(x=0;x<size;x++){set(6,x,x%2===0);set(x,6,x%2===0)}
 function finder(cx,cy){for(var dy=-4;dy<=4;dy++)for(var dx=-4;dx<=4;dx++){var d=Math.max(Math.abs(dx),Math.abs(dy));set(cx+dx,cy+dy,d!==2&&d!==4)}}
 finder(3,3);finder(size-4,3);finder(3,size-4);
 var pos=[];if(ver>1){var n=Math.floor(ver/7)+2,step=Math.ceil((ver*4+4)/(n*2-2))*2;pos=[6];for(var p=size-7;pos.length<n;p-=step)pos.splice(1,0,p)}
 pos.forEach(function(a,i){pos.forEach(function(b,j){if((i===0&&j===0)||(i===0&&j===pos.length-1)||(i===pos.length-1&&j===0))return;for(var dy=-2;dy<=2;dy++)for(var dx=-2;dx<=2;dx++)set(a+dx,b+dy,Math.max(Math.abs(dx),Math.abs(dy))!==1)})});
 function format(mask){var d=(0<<3)|mask,r=d,i;for(i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);var bits=((d<<10)|r)^0x5412;function g(i){return (bits>>>i)&1}
  for(i=0;i<=5;i++)set(8,i,g(i));set(8,7,g(6));set(8,8,g(7));set(7,8,g(8));for(i=9;i<15;i++)set(14-i,8,g(i));
  for(i=0;i<8;i++)set(size-1-i,8,g(i));for(i=8;i<15;i++)set(8,size-15+i,g(i));set(8,size-8,true)}
 format(0);
 if(ver>=7){var r=ver,i;for(i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);var vb=(ver<<12)|r;for(i=0;i<18;i++){var bit=(vb>>>i)&1,a=size-11+i%3,b=Math.floor(i/3);set(a,b,bit);set(b,a,bit)}}
 var idx=0,cw=e.codewords;
 for(var right=size-1;right>=1;right-=2){if(right===6)right=5;for(var vert=0;vert<size;vert++)for(var j=0;j<2;j++){var xx=right-j,up=((right+1)&2)===0,yy=up?size-1-vert:vert;if(!f[yy][xx]&&idx<cw.length*8){m[yy][xx]=((cw[idx>>>3]>>>(7-(idx&7)))&1)===1;idx++}}}
 function applyMask(mask){for(var y=0;y<size;y++)for(var x=0;x<size;x++){var inv;switch(mask){case 0:inv=(x+y)%2===0;break;case 1:inv=y%2===0;break;case 2:inv=x%3===0;break;case 3:inv=(x+y)%3===0;break;case 4:inv=(Math.floor(x/3)+Math.floor(y/2))%2===0;break;case 5:inv=x*y%2+x*y%3===0;break;case 6:inv=(x*y%2+x*y%3)%2===0;break;default:inv=((x+y)%2+x*y%3)%2===0}if(!f[y][x]&&inv)m[y][x]=!m[y][x]}}
 function penalty(){var s=0,x,y,dark=0;
  for(y=0;y<size;y++){var run=1;for(x=1;x<size;x++){if(m[y][x]===m[y][x-1]){run++;if(run===5)s+=3;else if(run>5)s++}else run=1}}
  for(x=0;x<size;x++){var run2=1;for(y=1;y<size;y++){if(m[y][x]===m[y-1][x]){run2++;if(run2===5)s+=3;else if(run2>5)s++}else run2=1}}
  for(y=0;y<size-1;y++)for(x=0;x<size-1;x++)if(m[y][x]===m[y][x+1]&&m[y][x]===m[y+1][x]&&m[y][x]===m[y+1][x+1])s+=3;
  for(y=0;y<size;y++)for(x=0;x<size;x++)if(m[y][x])dark++;
  s+=Math.floor(Math.abs(dark*20-size*size*10)/(size*size))*10;return s}
 var best=0,bp=1e9;
 for(var mk=0;mk<8;mk++){applyMask(mk);format(mk);var pn=penalty();if(pn<bp){bp=pn;best=mk}applyMask(mk)}
 applyMask(best);format(best);
 return {size:size,modules:m};
}
function draw(canvas,text,px){
 var q=build(text),quiet=4,n=q.size+quiet*2,scale=Math.max(1,Math.floor(px/n)),c=canvas.getContext("2d");
 canvas.width=canvas.height=n*scale;c.fillStyle="#fff";c.fillRect(0,0,canvas.width,canvas.height);c.fillStyle="#000";
 for(var y=0;y<q.size;y++)for(var x=0;x<q.size;x++)if(q.modules[y][x])c.fillRect((x+quiet)*scale,(y+quiet)*scale,scale,scale);
 return q.size;
}
w.ABDOQR={draw:draw,build:build};
})(window);
