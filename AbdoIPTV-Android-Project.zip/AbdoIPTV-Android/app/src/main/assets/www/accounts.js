(function(w){"use strict";
var KEY="abdo_servers",LIMIT=100;
function list(){try{var a=JSON.parse(localStorage.getItem(KEY)||"[]");return Array.isArray(a)?a:[]}catch(e){return []}}
function save(a){localStorage.setItem(KEY,JSON.stringify(a.slice(0,LIMIT)));return a.slice(0,LIMIT)}
function normalize(p){p=Object.assign({},p||{});if(p.type==="m3u"&&p.url){try{var u=new URL(p.url),un=u.searchParams.get("username"),pw=u.searchParams.get("password");if(/get\.php$/i.test(u.pathname)&&un&&pw){p.type="xtream";p.host=u.origin;p.username=un;p.password=pw}}catch(e){}}if(p.host)p.host=String(p.host).replace(/\/+$/,"");return p}
function upsert(p){var a=list(),v=normalize(p),i=a.findIndex(function(x){return x.id===v.id});if(!v.id)v.id="abdo-"+Date.now();if(i>=0)a[i]=v;else{if(a.length>=LIMIT)throw Error("الحد الأقصى 100 سيرفر");a.push(v)}save(a);return v}
function remove(id){save(list().filter(function(x){return x.id!==id}))}
w.ABDOAccounts={limit:LIMIT,list:list,save:save,normalize:normalize,upsert:upsert,remove:remove};
})(window);